"""Streaming Excel audit from a single SQLite snapshot; no fictional results."""

import io
import json
from collections import defaultdict
from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.chart import LineChart, Reference
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter
from .reporting import safe, utc
from .analytics import streaks
from .v2risk import local_day
from . import agreement, observer
from .lab import timing_bankroll
from .adaptive_entry import STARTING_CASH

MAX_ROWS = 1048576
TIMESTAMPS = {
    "time",
    "settled",
    "created",
    "trained",
    "verified_at",
    "start",
    "end",
    "finalized",
    "target",
    "book_timestamp",
    "training_end",
    "validation_start",
    "approved",
}


class Sheets:
    def __init__(self, wb):
        self.wb = wb
        self.counts = {}

    def create(self, name, headers):
        ws = self.wb.create_sheet(name)
        ws.freeze_panes = "A2"
        for i, header in enumerate(headers, 1):
            ws.column_dimensions[get_column_letter(i)].width = min(48, max(16, len(header) + 3))
        row = []
        for header in headers:
            cell = WriteOnlyCell(ws, value=header)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="17243A")
            row.append(cell)
        ws.append(row)
        self.counts[ws.title] = 1
        return ws

    def append(self, ws, values, formula_column=None):
        row = []
        for i, value in enumerate(values, 1):
            value = safe(value) if i != formula_column else value
            if isinstance(value, str) and len(value) > 32767:
                value = (
                    value[:32670] + " [AUDIT JSON TRUNCATED FOR EXCEL; FULL RECORD IS IN SQLITE]"
                )
            cell = WriteOnlyCell(ws, value=value)
            if isinstance(value, float):
                cell.number_format = "0.0000;[Red]-0.0000"
            row.append(cell)
        ws.append(row)
        self.counts[ws.title] += 1

    def table(self, name, headers, rows):
        ws = self.create(name, headers)
        first = ws
        part = 1
        for row in rows:
            if self.counts[ws.title] >= MAX_ROWS:
                ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{self.counts[ws.title]}"
                part += 1
                ws = self.create(name[:26] + f" {part}", headers)
            self.append(ws, row)
        ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{self.counts[ws.title]}"
        return first


def workbook(store, paper=None):
    wb = Workbook(write_only=True)
    sheets = Sheets(wb)
    with store.connect() as db:
        db.execute("BEGIN")
        names = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        row = db.execute("SELECT payload FROM state WHERE key='v2_experiment'").fetchone()
        experiment = (json.loads(row[0]) or {}) if row else {}
        dash = sheets.table(
            "Performance Dashboard",
            ["Metric", "Value"],
            [
                ["Scope", "PAPER / SHADOW ONLY; no real-money execution"],
                ["Experiment", experiment.get("status", "NOT STARTED")],
                ["Start UTC", utc(experiment.get("start"))],
                ["End UTC", utc(experiment.get("end"))],
                ["Trade records", db.execute("SELECT count(*) FROM v2_orders").fetchone()[0]],
                [
                    "Empty tables",
                    "No rows means no recorded results; it is not a profitable experiment",
                ],
                ["Paper accounts", "$1,000 per new account; no daily loss shutdown; positions hold until settlement"],
                ["Costs", "25% observed depth, 1 adverse tick, theta >= .095, no rebates"],
                ["Historical profitability", "UNKNOWN when causal entry/exit quotes are missing"],
            ],
        )

        def raw(sheet, table):
            if table not in names:
                return sheets.table(sheet, ["Status"], [])
            headers = [r["name"] for r in db.execute("PRAGMA table_info(" + table + ")")]
            rows = (
                [utc(r[k]) if k in TIMESTAMPS and r[k] is not None else r[k] for k in headers]
                for r in db.execute("SELECT * FROM " + table)
            )
            return sheets.table(
                sheet, [h + " UTC" if h in TIMESTAMPS else h for h in headers], rows
            )

        if "agreement_research" in names:
            sheets.table("Observer Rules", ["Rule", "Value"], [
                ["Starting cash per account", observer.STARTING_CASH],
                ["Fixed entry budget", observer.ENTRY_BUDGET],
                ["Daily gross loss limit (Chicago time)", observer.DAILY_LIMIT],
                ["Consecutive losses before Learn", observer.LOSS_STREAK],
                ["Recovery", "Next correct official outcome from an eligible pick made after the pause"],
                ["Exit", "Official settlement"],
            ])
            sheets.table("Agreement Scenarios",
                         ["Scenario","Entry seconds","Starting cash","Cash available","Entry budget",
                          "Daily loss limit","Loss streak limit","Minimum after-cost edge",
                          "Observed rounds","Officially settled rounds","Paper trades",
                          "Wins","Losses","Skips","Win rate","Net paper P&L",
                          "Rounds with either fill","P&L vs same-time control"], (
                [r[k] for k in ("label","checkpoint","starting_cash","cash","budget","daily_limit",
                                "streak_limit","min_edge","observed","settled_rounds","trades","wins","losses",
                                "skips","win_rate","net_pnl","paired_active","vs_control")]
                for r in agreement.summary(db)
            ))
            sheets.table("Agreement Round Audit",
                         ["Market","Entry seconds","Scenario","Observation UTC","Model","Model UP score",
                          "Predicted side","Opening reference","Closed candle price","Move (basis points)",
                          "Candle end UTC","Book source UTC","Book confirmed UTC","Eligible quantity",
                          "Eligible cost","Estimated after-cost edge","Filter reason","Account reason",
                          "Played quantity","Played cost","Played fee","Official outcome","Market close UTC",
                          "Net paper P&L"], (
                [r["slug"],r["checkpoint"],r["scenario"],utc(r["time"]),r["model"],r["prediction_up"],
                 r["direction"],r["opening_price"],r["candle_close"],r["gap_bps"],utc(r["candle_end"]),
                 utc(r["book_timestamp"]),utc(r["book_checked"]),r["quantity"],r["cost"],r["edge_rate"],
                 r["reason"],r["policy_reason"],r["played_quantity"],r["played_cost"],r["played_fee"],
                 r["outcome"],utc(r["settlement_end"]),r["pnl"]]
                for r in db.execute(agreement.results_sql()+" ORDER BY r.time,r.slug,r.checkpoint,r.scenario")
            ))
            raw("Observer Account Ledger", "observer_rounds")

        trade_headers = [
            "ID",
            "Account",
            "Market",
            "Side",
            "Entry UTC",
            "Model",
            "Estimated UP",
            "Quantity",
            "Total cost incl fees",
            "Fee",
            "Status",
            "Official outcome",
            "Net P&L",
            "Settlement UTC",
            "Audit JSON",
            "Strategy segment",
            "P&L audit formula",
        ]
        trades = sheets.create("Trade History", trade_headers)
        for i, r in enumerate(db.execute("SELECT * FROM v2_orders ORDER BY id"), 2):
            sheets.append(
                trades,
                [
                    r["id"],
                    r["account"],
                    r["slug"],
                    r["side"],
                    utc(r["time"]),
                    r["model"],
                    r["probability"],
                    r["quantity"],
                    r["cost"],
                    r["fee"],
                    r["status"],
                    r["result"],
                    r["pnl"],
                    utc(r["settled"]),
                    r["details"],
                    r["segment"],
                    f'=IF(K{i}="SETTLED",IF(D{i}=L{i},H{i},0)-I{i},"")',
                ],
                formula_column=17,
            )
        raw("Skipped Markets", "v2_skips")
        raw("UP DOWN History", "verified_markets")
        raw("Strategy Accounts", "v2_accounts")
        raw("Learning History", "model_runs")
        raw("Strategy Change History", "strategy_changes")
        raw("Trend Analyses", "trend_runs")
        raw("Risk Events", "risk_events")
        raw("Predictions", "v2_decisions")
        raw("Hourly Checkpoints", "v2_hourly")
        raw("Adaptive Selections", "adaptive_selections")
        raw("Adaptive Decisions", "adaptive_decisions")
        raw("Adaptive Market Windows", "adaptive_windows")
        if {"adaptive_windows", "adaptive_decisions"} <= names:
            sheets.table("Adaptive Labeled Observations",
                         ["Market","Account","Observation UTC","Model","Estimated UP","Decision",
                          "Reason","Official outcome","Window end UTC","Audit JSON"], (
                [r["slug"],r["account"],utc(r["time"]),r["model"],r["up"],r["decision"],
                 r["reason"],r["outcome"],utc(r["end"]),r["details"]]
                for r in db.execute("""SELECT d.*,v.outcome,v.end FROM adaptive_decisions d
                    JOIN verified_markets v ON v.slug=d.slug
                    WHERE d.up IS NOT NULL AND d.time<v.end ORDER BY d.time,d.id""")
            ))
        if "adaptive_later" in names:
            sheets.table("Later Entry Comparison",
                         ["Market","Account","Side","Actual entry UTC","Actual entry seconds",
                          "Delay seconds","Target UTC","Observed UTC","Book source UTC","Later quote status",
                          "Official outcome","Early P&L","Later P&L","Later minus early","Later cost","Later fee",
                          "Later quantity","Audit JSON"], (
                [r["slug"],r["account"],r["side"],utc(r["entry"]),r["entry_seconds"],r["delay"],
                 utc(r["target"]),utc(r["time"]),utc(r["book_timestamp"]),r["reason"],r["result"],
                 r["early_pnl"],r["late_pnl"],
                 r["late_pnl"]-r["early_pnl"] if r["late_pnl"] is not None else None,
                 r["cost"],r["fee"],r["quantity"],r["details"]]
                for r in db.execute("""SELECT l.*,o.slug,o.account,o.side,o.time AS entry,
                    o.time-w.start AS entry_seconds,o.result,o.pnl AS early_pnl,
                    CASE WHEN o.status='SETTLED' AND l.quantity>0
                         THEN (CASE WHEN o.side=o.result THEN l.quantity ELSE 0 END)-l.cost END AS late_pnl
                    FROM adaptive_later l JOIN v2_orders o ON o.id=l.order_id
                    JOIN adaptive_windows w ON w.slug=o.slug ORDER BY o.time,o.id,l.delay""")
            ))
        raw("Approved Configurations", "approved_configs")
        raw("Smart Flip Research", "v2_smart_experiments")
        raw("Smart Flip Actions", "v2_smart_actions")
        raw("Lab Trade History", "lab_orders")
        raw("Lab Skipped Markets", "lab_skips")
        raw("Research Runs", "lab_runs")
        raw("Human Review", "intervention_requests")
        raw("Model Timing Predictions", "lab_predictions")
        sheets.table("Bug Log", ["UTC", "Severity", "Observed issue"], (
            [utc(row["time"]), row["level"], row["message"]]
            for row in db.execute("SELECT time,level,message FROM events WHERE level IN ('WARNING','ERROR') ORDER BY id")
        ))
        if {"lab_configs","lab_orders"} <= names:
            timing_rows = db.execute("""SELECT a.family,a.version,a.stake,a.checkpoint,
                count(*) AS rounds,sum(e.pnl),sum(b.pnl),sum(e.pnl-b.pnl)
                FROM lab_configs a JOIN lab_configs z
                ON z.version=a.version AND z.family=a.family AND z.stake=a.stake AND z.exit='HOLD'
                AND z.checkpoint=90 AND z.id LIKE 'timing/%'
                AND (a.id LIKE 'timing/v2/%')=(z.id LIKE 'timing/v2/%')
                JOIN lab_orders e ON e.config=a.id AND e.status='SETTLED'
                JOIN lab_orders b ON b.config=z.id AND b.slug=e.slug AND b.status='SETTLED'
                WHERE a.exit='HOLD' AND a.id LIKE 'timing/%'
                GROUP BY a.family,a.version,a.stake,a.checkpoint
                ORDER BY a.family,a.version,a.stake,a.checkpoint""")
            sheets.table("Timing vs 90s Matched", ["Model","Version","Stake","Entry seconds",
                "Matched rounds","Entry net P&L","90s net P&L","Difference"], timing_rows)
        if {"adaptive_windows", "lab_configs", "lab_orders", "lab_skips"} <= names:
            sheets.table("Adaptive vs Fixed Timing",
                         ["Fixed model","Stake","Fixed entry seconds","Comparable rounds",
                          "Adaptive entries","Fixed entries","Adaptive net P&L","Fixed net P&L",
                          "Adaptive minus fixed"], db.execute("""
                WITH paired AS (
                    SELECT c.version,c.stake,c.checkpoint,w.slug,a.id AS adaptive_order,
                           f.id AS fixed_order,coalesce(a.pnl,0) AS adaptive_pnl,coalesce(f.pnl,0) AS fixed_pnl
                    FROM adaptive_windows w JOIN verified_markets v ON v.slug=w.slug
                    JOIN lab_configs c ON c.exit='HOLD' AND c.id LIKE 'timing/v2/%'
                    LEFT JOIN v2_orders a ON a.slug=w.slug AND a.account='adaptive-'||cast(c.stake AS INTEGER)
                    LEFT JOIN v2_skips s ON s.slug=w.slug AND s.account='adaptive-'||cast(c.stake AS INTEGER)
                         AND s.checkpoint=0
                    LEFT JOIN lab_orders f ON f.slug=w.slug AND f.config=c.id
                    LEFT JOIN lab_skips fs ON fs.slug=w.slug AND fs.config=c.id
                    WHERE (a.status='SETTLED' OR (a.id IS NULL AND s.id IS NOT NULL))
                      AND (f.status='SETTLED' OR (f.id IS NULL AND fs.config IS NOT NULL))
                )
                SELECT version,stake,checkpoint,count(*),count(adaptive_order),count(fixed_order),
                       sum(adaptive_pnl),sum(fixed_pnl),sum(adaptive_pnl-fixed_pnl)
                FROM paired GROUP BY version,stake,checkpoint ORDER BY version,stake,checkpoint
                """))
        model_rows = []
        if "model_registry" in names:
            for r in db.execute("SELECT * FROM model_registry"):
                meta = json.loads(r["metadata"])
                test = meta.get("test", {})
                model_rows.append(
                    [
                        r["kind"],
                        r["version"],
                        utc(r["trained"]),
                        r["dataset"],
                        test.get("n"),
                        test.get("accuracy"),
                        test.get("brier"),
                        meta.get("split"),
                        r["sha256"],
                        "UNKNOWN",
                        meta.get("configuration"),
                    ]
                )
        sheets.table(
            "Model Comparison",
            [
                "Family",
                "Version",
                "Trained UTC",
                "Dataset SHA",
                "Test examples",
                "Accuracy",
                "Brier",
                "Split",
                "Artifact SHA",
                "Profitability",
                "Configuration",
            ],
            model_rows,
        )
        leaderboard = []
        if "lab_configs" in names:
            for config in db.execute("SELECT * FROM lab_configs").fetchall():
                opening_cash = timing_bankroll(config["id"])
                equity = peak = opening_cash
                dd = gains = losses = 0.0
                n = wins = 0
                for o in db.execute(
                    "SELECT pnl FROM lab_orders WHERE config=? AND pnl IS NOT NULL ORDER BY settled,id",
                    (config["id"],),
                ):
                    n += 1
                    wins += o["pnl"] > 0
                    equity += o["pnl"]
                    peak = max(peak, equity)
                    dd = max(dd, peak - equity)
                    gains += max(0, o["pnl"])
                    losses -= min(0, o["pnl"])
                skips = db.execute(
                    "SELECT count(*) FROM lab_skips WHERE config=?", (config["id"],)
                ).fetchone()[0]
                leaderboard.append(
                    [
                        config["version"],
                        config["checkpoint"],
                        config["exit"],
                        config["stake"],
                        equity - opening_cash if n else None,
                        (equity - opening_cash) / opening_cash if n else None,
                        n,
                        skips,
                        wins / n if n else None,
                        dd if n else None,
                        gains / losses if losses else None,
                        config["status"],
                        "OBSERVED ONLY" if n else "UNKNOWN",
                    ]
                )
        sheets.table(
            "Simulation Leaderboard",
            [
                "Version",
                "Entry seconds",
                "Exit",
                "Stake",
                "Net P&L",
                "Return",
                "Trades",
                "Skips",
                "Win rate",
                "Max drawdown USD",
                "Profit factor",
                "Scope",
                "Completeness",
            ],
            leaderboard,
        )
        sheets.table(
            "Smart Exit Comparison",
            [
                "Version",
                "Entry",
                "Exit",
                "Stake",
                "Net P&L",
                "Return",
                "Trades",
                "Skips",
                "Win rate",
                "Drawdown",
                "Profit factor",
                "Scope",
                "Completeness",
            ],
            leaderboard,
        )
        done_query = "SELECT account,slug,side,model,settled,pnl,details FROM v2_orders WHERE pnl IS NOT NULL ORDER BY settled,id"
        sheets.table(
            "WIN LOSS History",
            ["Account", "Market", "Settlement UTC", "Result", "Net P&L", "Model"],
            (
                [
                    r["account"],
                    r["slug"],
                    utc(r["settled"]),
                    "WIN" if r["pnl"] > 0 else "LOSS" if r["pnl"] < 0 else "FLAT",
                    r["pnl"],
                    r["model"],
                ]
                for r in db.execute(done_query)
            ),
        )
        daily = defaultdict(lambda: [0, 0.0, 0])
        timing = defaultdict(lambda: [0, 0.0])
        trade_values = []
        for r in db.execute(done_query):
            v = daily[(r["account"], local_day(r["settled"]))]
            v[0] += 1
            v[1] += r["pnl"]
            v[2] += r["pnl"] > 0
            checkpoint = (
                json.loads(r["details"]).get("prediction", {}).get("checkpoint", "ADAPTIVE" if r["account"].startswith("adaptive-") else "NOT AVAILABLE")
            )
            v = timing[(r["account"], str(checkpoint))]
            v[0] += 1
            v[1] += r["pnl"]
            if r["account"] == "primary":
                trade_values.append("WIN" if r["pnl"] > 0 else "LOSS" if r["pnl"] < 0 else "FLAT")
        sheets.table(
            "Daily Performance",
            ["Account", "Chicago date", "Settled trades", "Net P&L", "Win rate"],
            ([a, d, v[0], v[1], v[2] / v[0]] for (a, d), v in sorted(daily.items())),
        )
        sheets.table(
            "Entry Time Comparison",
            ["Account", "Checkpoint seconds", "Trades", "Net P&L"],
            ([a, c, v[0], v[1]] for (a, c), v in sorted(timing.items())),
        )
        outcomes = [
            r[0]
            for r in db.execute("SELECT outcome FROM verified_markets ORDER BY end DESC LIMIT 50")
        ][::-1]
        sheets.table(
            "Streak Statistics",
            ["Scope", "Statistics"],
            [
                ["Market", streaks(outcomes, "UP", "DOWN")],
                ["Primary trades", streaks(trade_values, "WIN", "LOSS")],
                ["Verified count", len(outcomes)],
            ],
        )
        primary = sheets.create("Primary Equity", ["UTC", "Equity", "Drawdown USD"])
        sheets.append(primary, ["INITIAL", 100, 0])
        curve = sheets.create(
            "Equity and Drawdown", ["UTC", "Account", "Settled equity", "Peak", "Drawdown USD"]
        )
        for a in db.execute("SELECT id FROM v2_accounts").fetchall():
            equity = peak = STARTING_CASH if a["id"].startswith("adaptive-") else 100
            sheets.append(curve, ["INITIAL", a["id"], equity, equity, 0])
            for o in db.execute(
                "SELECT pnl,settled FROM v2_orders WHERE account=? AND pnl IS NOT NULL ORDER BY settled,id",
                (a["id"],),
            ):
                equity += o["pnl"]
                peak = max(peak, equity)
                sheets.append(curve, [utc(o["settled"]), a["id"], equity, peak, peak - equity])
                if a["id"] == "primary":
                    sheets.append(primary, [utc(o["settled"]), equity, peak - equity])
        chart = LineChart()
        chart.title = "Primary settled equity (not mark-to-market)"
        chart.y_axis.title = "USD"
        chart.add_data(
            Reference(
                primary, min_col=2, max_col=2, min_row=1, max_row=sheets.counts[primary.title]
            ),
            titles_from_data=True,
        )
        dash.add_chart(chart, "D2")
    output = io.BytesIO()
    wb.save(output)
    return output.getvalue()
