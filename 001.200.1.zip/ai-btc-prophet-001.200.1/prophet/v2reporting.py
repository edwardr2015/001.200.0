"""Streaming Excel audit from a single SQLite snapshot; no fictional results."""

import io
import json
from collections import defaultdict
from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.chart import LineChart, Reference
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter
from .reporting import safe, utc
from .analytics import streaks
from .v2risk import local_day

MAX_ROWS = 1048576
TIMESTAMPS = {
    "time",
    "settled",
    "created",
    "trained",
    "verified_at",
    "start",
    "end",
    "training_end",
    "validation_start",
    "approved",
}


class Sheets:
    def __init__(self, wb):
        self.wb = wb
        self.counts = {}

    def create(self, name, headers):
        ws = self.wb.create_sheet(name)
        ws.freeze_panes = "A2"
        for i, header in enumerate(headers, 1):
            ws.column_dimensions[get_column_letter(i)].width = min(48, max(16, len(header) + 3))
        row = []
        for header in headers:
            cell = WriteOnlyCell(ws, value=header)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="17243A")
            row.append(cell)
        ws.append(row)
        self.counts[ws.title] = 1
        return ws

    def append(self, ws, values, formula_column=None):
        row = []
        for i, value in enumerate(values, 1):
            value = safe(value) if i != formula_column else value
            if isinstance(value, str) and len(value) > 32767:
                value = (
                    value[:32670] + " [AUDIT JSON TRUNCATED FOR EXCEL; FULL RECORD IS IN SQLITE]"
                )
            cell = WriteOnlyCell(ws, value=value)
            if isinstance(value, float):
                cell.number_format = "0.0000;[Red]-0.0000"
            row.append(cell)
        ws.append(row)
        self.counts[ws.title] += 1

    def table(self, name, headers, rows):
        ws = self.create(name, headers)
        first = ws
        part = 1
        for row in rows:
            if self.counts[ws.title] >= MAX_ROWS:
                ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{self.counts[ws.title]}"
                part += 1
                ws = self.create(name[:26] + f" {part}", headers)
            self.append(ws, row)
        ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{self.counts[ws.title]}"
        return first


def workbook(store, paper=None):
    wb = Workbook(write_only=True)
    sheets = Sheets(wb)
    with store.connect() as db:
        db.execute("BEGIN")
        names = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        row = db.execute("SELECT payload FROM state WHERE key='v2_experiment'").fetchone()
        experiment = (json.loads(row[0]) or {}) if row else {}
        dash = sheets.table(
            "Performance Dashboard",
            ["Metric", "Value"],
            [
                ["Scope", "PAPER / SHADOW ONLY; no real-money execution"],
                ["Experiment", experiment.get("status", "NOT STARTED")],
                ["Start UTC", utc(experiment.get("start"))],
                ["End UTC", utc(experiment.get("end"))],
                ["Trade records", db.execute("SELECT count(*) FROM v2_orders").fetchone()[0]],
                [
                    "Empty tables",
                    "No rows means no recorded results; it is not a profitable experiment",
                ],
                ["Timing research", "$100 per account; balances and liquidity enforced; no daily loss shutdown"],
                ["Costs", "25% observed depth, 1 adverse tick, theta >= .095, no rebates"],
                ["Historical profitability", "UNKNOWN when causal entry/exit quotes are missing"],
            ],
        )

        def raw(sheet, table):
            if table not in names:
                return sheets.table(sheet, ["Status"], [])
            headers = [r["name"] for r in db.execute("PRAGMA table_info(" + table + ")")]
            rows = (
                [utc(r[k]) if k in TIMESTAMPS and r[k] is not None else r[k] for k in headers]
                for r in db.execute("SELECT * FROM " + table)
            )
            return sheets.table(
                sheet, [h + " UTC" if h in TIMESTAMPS else h for h in headers], rows
            )

        trade_headers = [
            "ID",
            "Account",
            "Market",
            "Side",
            "Entry UTC",
            "Model",
            "Estimated UP",
            "Quantity",
            "Total cost incl fees",
            "Fee",
            "Status",
            "Official outcome",
            "Net P&L",
            "Settlement UTC",
            "Audit JSON",
            "Strategy segment",
            "P&L audit formula",
        ]
        trades = sheets.create("Trade History", trade_headers)
        for i, r in enumerate(db.execute("SELECT * FROM v2_orders ORDER BY id"), 2):
            sheets.append(
                trades,
                [
                    r["id"],
                    r["account"],
                    r["slug"],
                    r["side"],
                    utc(r["time"]),
                    r["model"],
                    r["probability"],
                    r["quantity"],
                    r["cost"],
                    r["fee"],
                    r["status"],
                    r["result"],
                    r["pnl"],
                    utc(r["settled"]),
                    r["details"],
                    r["segment"],
                    f'=IF(K{i}="SETTLED",IF(D{i}=L{i},H{i},0)-I{i},"")',
                ],
                formula_column=17,
            )
        raw("Skipped Markets", "v2_skips")
        raw("UP DOWN History", "verified_markets")
        raw("Strategy Accounts", "v2_accounts")
        raw("Learning History", "model_runs")
        raw("Strategy Change History", "strategy_changes")
        raw("Trend Analyses", "trend_runs")
        raw("Risk Events", "risk_events")
        raw("Predictions", "v2_decisions")
        raw("Hourly Checkpoints", "v2_hourly")
        raw("Adaptive Selections", "adaptive_selections")
        raw("Approved Configurations", "approved_configs")
        raw("Smart Flip Research", "v2_smart_experiments")
        raw("Smart Flip Actions", "v2_smart_actions")
        raw("Lab Trade History", "lab_orders")
        raw("Lab Skipped Markets", "lab_skips")
        raw("Research Runs", "lab_runs")
        raw("Human Review", "intervention_requests")
        raw("Model Timing Predictions", "lab_predictions")
        sheets.table("Bug Log", ["UTC", "Severity", "Observed issue"], (
            [utc(row["time"]), row["level"], row["message"]]
            for row in db.execute("SELECT time,level,message FROM events WHERE level IN ('WARNING','ERROR') ORDER BY id")
        ))
        if {"lab_configs","lab_orders"} <= names:
            timing_rows = db.execute("""SELECT a.family,a.version,a.stake,a.checkpoint,
                count(*) AS rounds,sum(e.pnl),sum(b.pnl),sum(e.pnl-b.pnl)
                FROM lab_configs a JOIN lab_configs z
                ON z.version=a.version AND z.family=a.family AND z.stake=a.stake AND z.exit='HOLD'
                AND z.checkpoint=90 AND z.id LIKE 'timing/%'
                JOIN lab_orders e ON e.config=a.id AND e.status='SETTLED'
                JOIN lab_orders b ON b.config=z.id AND b.slug=e.slug AND b.status='SETTLED'
                WHERE a.exit='HOLD' AND a.id LIKE 'timing/%'
                GROUP BY a.family,a.version,a.stake,a.checkpoint
                ORDER BY a.family,a.version,a.stake,a.checkpoint""")
            sheets.table("Timing vs 90s Matched", ["Model","Version","Stake","Entry seconds",
                "Matched rounds","Entry net P&L","90s net P&L","Difference"], timing_rows)
        model_rows = []
        if "model_registry" in names:
            for r in db.execute("SELECT * FROM model_registry"):
                meta = json.loads(r["metadata"])
                test = meta.get("test", {})
                model_rows.append(
                    [
                        r["kind"],
                        r["version"],
                        utc(r["trained"]),
                        r["dataset"],
                        test.get("n"),
                        test.get("accuracy"),
                        test.get("brier"),
                        meta.get("split"),
                        r["sha256"],
                        "UNKNOWN",
                        meta.get("configuration"),
                    ]
                )
        sheets.table(
            "Model Comparison",
            [
                "Family",
                "Version",
                "Trained UTC",
                "Dataset SHA",
                "Test examples",
                "Accuracy",
                "Brier",
                "Split",
                "Artifact SHA",
                "Profitability",
                "Configuration",
            ],
            model_rows,
        )
        leaderboard = []
        if "lab_configs" in names:
            for config in db.execute("SELECT * FROM lab_configs").fetchall():
                equity = peak = 100.0
                dd = gains = losses = 0.0
                n = wins = 0
                for o in db.execute(
                    "SELECT pnl FROM lab_orders WHERE config=? AND pnl IS NOT NULL ORDER BY settled,id",
                    (config["id"],),
                ):
                    n += 1
                    wins += o["pnl"] > 0
                    equity += o["pnl"]
                    peak = max(peak, equity)
                    dd = max(dd, peak - equity)
                    gains += max(0, o["pnl"])
                    losses -= min(0, o["pnl"])
                skips = db.execute(
                    "SELECT count(*) FROM lab_skips WHERE config=?", (config["id"],)
                ).fetchone()[0]
                leaderboard.append(
                    [
                        config["version"],
                        config["checkpoint"],
                        config["exit"],
                        config["stake"],
                        equity - 100 if n else None,
                        (equity - 100) / 100 if n else None,
                        n,
                        skips,
                        wins / n if n else None,
                        dd if n else None,
                        gains / losses if losses else None,
                        "FORWARD SHADOW",
                        "OBSERVED ONLY" if n else "UNKNOWN",
                    ]
                )
        sheets.table(
            "Simulation Leaderboard",
            [
                "Version",
                "Entry seconds",
                "Exit",
                "Stake",
                "Net P&L",
                "Return",
                "Trades",
                "Skips",
                "Win rate",
                "Max drawdown USD",
                "Profit factor",
                "Scope",
                "Completeness",
            ],
            leaderboard,
        )
        sheets.table(
            "Smart Exit Comparison",
            [
                "Version",
                "Entry",
                "Exit",
                "Stake",
                "Net P&L",
                "Return",
                "Trades",
                "Skips",
                "Win rate",
                "Drawdown",
                "Profit factor",
                "Scope",
                "Completeness",
            ],
            leaderboard,
        )
        done_query = "SELECT account,slug,side,model,settled,pnl,details FROM v2_orders WHERE pnl IS NOT NULL ORDER BY settled,id"
        sheets.table(
            "WIN LOSS History",
            ["Account", "Market", "Settlement UTC", "Result", "Net P&L", "Model"],
            (
                [
                    r["account"],
                    r["slug"],
                    utc(r["settled"]),
                    "WIN" if r["pnl"] > 0 else "LOSS" if r["pnl"] < 0 else "FLAT",
                    r["pnl"],
                    r["model"],
                ]
                for r in db.execute(done_query)
            ),
        )
        daily = defaultdict(lambda: [0, 0.0, 0])
        timing = defaultdict(lambda: [0, 0.0])
        trade_values = []
        for r in db.execute(done_query):
            v = daily[(r["account"], local_day(r["settled"]))]
            v[0] += 1
            v[1] += r["pnl"]
            v[2] += r["pnl"] > 0
            checkpoint = (
                json.loads(r["details"]).get("prediction", {}).get("checkpoint", "NOT AVAILABLE")
            )
            v = timing[(r["account"], str(checkpoint))]
            v[0] += 1
            v[1] += r["pnl"]
            if r["account"] == "primary":
                trade_values.append("WIN" if r["pnl"] > 0 else "LOSS" if r["pnl"] < 0 else "FLAT")
        sheets.table(
            "Daily Performance",
            ["Account", "Chicago date", "Settled trades", "Net P&L", "Win rate"],
            ([a, d, v[0], v[1], v[2] / v[0]] for (a, d), v in sorted(daily.items())),
        )
        sheets.table(
            "Entry Time Comparison",
            ["Account", "Checkpoint seconds", "Trades", "Net P&L"],
            ([a, c, v[0], v[1]] for (a, c), v in sorted(timing.items())),
        )
        outcomes = [
            r[0]
            for r in db.execute("SELECT outcome FROM verified_markets ORDER BY end DESC LIMIT 50")
        ][::-1]
        sheets.table(
            "Streak Statistics",
            ["Scope", "Statistics"],
            [
                ["Market", streaks(outcomes, "UP", "DOWN")],
                ["Primary trades", streaks(trade_values, "WIN", "LOSS")],
                ["Verified count", len(outcomes)],
            ],
        )
        primary = sheets.create("Primary Equity", ["UTC", "Equity", "Drawdown USD"])
        sheets.append(primary, ["INITIAL", 100, 0])
        curve = sheets.create(
            "Equity and Drawdown", ["UTC", "Account", "Settled equity", "Peak", "Drawdown USD"]
        )
        for a in db.execute("SELECT id FROM v2_accounts").fetchall():
            equity = peak = 100.0
            sheets.append(curve, ["INITIAL", a["id"], 100, 100, 0])
            for o in db.execute(
                "SELECT pnl,settled FROM v2_orders WHERE account=? AND pnl IS NOT NULL ORDER BY settled,id",
                (a["id"],),
            ):
                equity += o["pnl"]
                peak = max(peak, equity)
                sheets.append(curve, [utc(o["settled"]), a["id"], equity, peak, peak - equity])
                if a["id"] == "primary":
                    sheets.append(primary, [utc(o["settled"]), equity, peak - equity])
        chart = LineChart()
        chart.title = "Primary settled equity (not mark-to-market)"
        chart.y_axis.title = "USD"
        chart.add_data(
            Reference(
                primary, min_col=2, max_col=2, min_row=1, max_row=sheets.counts[primary.title]
            ),
            titles_from_data=True,
        )
        dash.add_chart(chart, "D2")
    output = io.BytesIO()
    wb.save(output)
    return output.getvalue()
