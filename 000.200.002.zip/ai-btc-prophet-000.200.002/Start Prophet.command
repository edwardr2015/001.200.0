#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
trap 'echo "Startup stopped. Read the error above, then press Enter to close."; read -r' ERR
if ! command -v python3 >/dev/null; then
  echo "Install Python 3.12 from https://www.python.org/downloads/macos/ and try again."
  exit 1
fi
python3 -c 'import sys; assert sys.version_info >= (3,11), "Python 3.11 or newer is required"'
if [ ! -x .venv/bin/python ]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install -e .
export PROPHET_DB="${PROPHET_DB:-$PWD/data/timing/prophet.sqlite3}"
export PROPHET_HISTORY_DB="${PROPHET_HISTORY_DB:-$PWD/data/timing/history.sqlite3}"
export PROPHET_FRESH_RESEARCH="${PROPHET_FRESH_RESEARCH:-1}"
export PROPHET_RESEARCH_MODELS="${PROPHET_RESEARCH_MODELS:-ensemble,random_forest,hmm,lightgbm,xgboost}"
export PROPHET_AUTH_REQUIRED="${PROPHET_AUTH_REQUIRED:-0}"
if [ "$PROPHET_AUTH_REQUIRED" = "1" ] && [ ! -f "$(dirname "$PROPHET_DB")/auth.json" ]; then
  .venv/bin/python -m scripts.setup_auth
fi
echo "Opening your private dashboard. Trading starts OFF. Keep this window open."
(sleep 2; open http://127.0.0.1:8000) &
exec .venv/bin/python -m uvicorn prophet.app:app --host 127.0.0.1 --port 8000 --workers 1
