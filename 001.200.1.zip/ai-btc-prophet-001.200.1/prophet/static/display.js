'use strict';

async function updateDisplay() {
  const element = id => document.getElementById(id);
  try {
    const response = await fetch('/api/display');
    if (!response.ok) throw new Error('Display disabled or unavailable');
    const data = await response.json();
    element('display-time').textContent = new Date(data.server_time * 1000).toISOString();
    const reference = data.reference;
    const age = reference ? Math.floor(data.server_time - reference.timestamp) : null;
    element('display-price').textContent = reference ?
      `BRTI $${Number(reference.price).toLocaleString('en-US', {minimumFractionDigits: 2})}` :
      'UNAVAILABLE';
    element('display-status').textContent = age === null ? 'No verified reference data' :
      `${age}s old · ${age < 0 || age > 15 ? 'Delayed' : 'Source timestamp'}`;
    renderDirection(element('display-call'), element('display-tally'), data.decision_display);
    renderBenchmark(element('display-results'), data.benchmark_results);
    const timing = element('display-timing');
    timing.replaceChildren();
    for (const result of data.timing) {
      const line = document.createElement('p');
      line.textContent = `+${result.checkpoint}s · ${result.trades ?
        `${result.trades} settled · $${result.pnl.toFixed(2)} net paper P&L` :
        'Awaiting settled results'}`;
      timing.append(line);
    }
  } catch (error) {
    element('display-status').textContent = error.message;
    renderDirection(element('display-call'), element('display-tally'), null);
  }
}
updateDisplay();
setInterval(updateDisplay, 3000);
