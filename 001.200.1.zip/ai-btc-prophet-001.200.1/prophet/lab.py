"""Independent forward shadow configurations sharing causal market observations."""

import json
import math
import pickle
import time
from .models import Models
from .execution import execute
from .v2risk import CHECKPOINTS, entry_block

EXITS = ("HOLD", "TAKE_PROFIT_1.4", "DYNAMIC")
MODEL_ERRORS = (ValueError, ImportError, OSError, TypeError, RuntimeError, EOFError, pickle.UnpicklingError)


class Lab:
    def __init__(self, store, paper):
        self.store, self.paper = store, paper
        self.models = Models(store)
        self.model_failures = set()
        from .smart import SmartResearch

        self.flip = SmartResearch(store, paper, version=2)
        with store.connect() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS lab_configs (
              id TEXT PRIMARY KEY, family TEXT, version TEXT, checkpoint INTEGER,
              exit TEXT, stake REAL, status TEXT, cash REAL DEFAULT 100,
              created REAL);
            CREATE TABLE IF NOT EXISTS lab_predictions (
              config_family TEXT, version TEXT, slug TEXT, checkpoint INTEGER,
              time REAL, up REAL, features TEXT, PRIMARY KEY(version,slug,checkpoint));
            CREATE TABLE IF NOT EXISTS lab_orders (
              id INTEGER PRIMARY KEY, config TEXT, slug TEXT, side TEXT, time REAL,
              quantity REAL, remaining REAL, cost REAL, proceeds REAL DEFAULT 0,
              fees REAL, status TEXT, pnl REAL, settled REAL, details TEXT,
              UNIQUE(config,slug));
            CREATE TABLE IF NOT EXISTS lab_books (slug TEXT,time REAL,payload TEXT,PRIMARY KEY(slug,time));
            CREATE INDEX IF NOT EXISTS lab_orders_settled ON lab_orders(config,settled,id);
            CREATE TABLE IF NOT EXISTS lab_processed (slug TEXT, checkpoint INTEGER, PRIMARY KEY(slug,checkpoint));
            CREATE TABLE IF NOT EXISTS lab_skips (
              config TEXT, slug TEXT, time REAL, reason TEXT, PRIMARY KEY(config,slug));
            CREATE TABLE IF NOT EXISTS lab_runs (
              id INTEGER PRIMARY KEY, time REAL, kind TEXT, details TEXT);
            CREATE TABLE IF NOT EXISTS adaptive_selections (
              slug TEXT PRIMARY KEY, time REAL, selected TEXT, reason TEXT, mode TEXT);
            """)
        from .adaptive import Adaptive

        self.adaptive = Adaptive(store, paper)
        self.refresh()

    def refresh(self):
        self.models.sync_logistic()
        with self.store.connect() as db:
            db.execute("""UPDATE lab_configs SET status='ARCHIVED PROTOCOL'
                        WHERE id NOT LIKE 'timing/%' AND status='FORWARD SHADOW'""")
            for family in self.models.catalog():
                run = (
                    family["versions"][0]
                    if family["versions"] and family["status"] == "AVAILABLE"
                    else None
                )
                version = run["version"] if run else "UNAVAILABLE-" + family["id"]
                db.execute(
                    "UPDATE lab_configs SET status='ARCHIVED VERSION' WHERE family=? AND version!=? AND status='FORWARD SHADOW'",
                    (family["id"], version),
                )
                for checkpoint in CHECKPOINTS:
                    for exit in EXITS:
                        for stake in (1, 2, 3):
                            id = f"timing/{version}/{checkpoint}/{exit}/{stake}"
                            db.execute(
                                "INSERT OR IGNORE INTO lab_configs VALUES (?,?,?,?,?,?,?,?,?)",
                                (
                                    id,
                                    family["id"],
                                    version,
                                    checkpoint,
                                    exit,
                                    stake,
                                    "FORWARD SHADOW" if run else family["status"],
                                    100,
                                    time.time(),
                                ),
                            )

    def predict(self, version, x, checkpoint, slug=None, now=None):
        from .models import feature_sequence

        now = time.time() if now is None else now
        sequence = feature_sequence(
            self.store, x, checkpoint, slug or (self.store.get("market") or {}).get("slug", ""), now
        )
        return self.models.predict(version, x, sequence)

    def tick(self, now=None):
        live_clock = now is None
        now = time.time() if live_clock else now
        self.exit_and_settle(now)
        self.flip.tick(now)
        if self.store.get("mode") not in ("LEARN", "SIMULATE") or self.store.get("emergency", False):
            return
        if now - getattr(self, "refreshed", 0) > 60:
            self.refresh()
            self.refreshed = now
        with self.store.connect() as db:
            rows = db.execute("""SELECT p.*, b.payload AS captured_book
                  FROM v2_decisions p LEFT JOIN lab_processed d
                  ON d.slug=p.slug AND d.checkpoint=p.checkpoint
                  LEFT JOIN timing_checkpoint_books b ON p.slug=b.slug AND p.checkpoint=b.checkpoint
                  WHERE d.slug IS NULL ORDER BY p.time,p.checkpoint""").fetchall()
        for decision in rows:
            details = json.loads(decision["details"])
            if details.get("protocol") != "fixed-timing-v1":
                # The prior protocol's observations and results remain archived.
                with self.store.connect() as db:
                    db.execute("INSERT OR IGNORE INTO lab_processed VALUES (?,?)",
                               (decision["slug"],decision["checkpoint"]))
                continue
            observed_at = decision["time"]
            checkpoint = decision["checkpoint"]
            slug = decision["slug"]
            deadline = min(details["window_start"]+checkpoint+3, details["window_end"])
            book = json.loads(decision["captured_book"]) if decision["captured_book"] else None
            reason = None
            needed = ("theta","tick","quantum","momentum_60","trend_300","volatility")
            if now > deadline or now >= details["window_end"]:
                reason = decision["reason"] if decision["up"] is None else "MISSED_CHECKPOINT"
            elif decision["up"] is None or not all(k in details for k in needed):
                reason = decision["reason"]
            elif (not book or book["slug"] != slug or book.get("state") != "MARKET_STATE_OPEN"
                  or not 0 <= observed_at-book["timestamp"] <= 15
                  or not 0 <= observed_at-details["reference_timestamp"] <= 15):
                reason = "STALE_OR_MISSING_CHECKPOINT_SNAPSHOT"
            with self.store.connect() as db:
                configs = [dict(r) for r in db.execute(
                    "SELECT * FROM lab_configs WHERE checkpoint=? AND status='FORWARD SHADOW' AND id LIKE 'timing/%'",
                    (checkpoint,))]
            probabilities = {}
            x = []
            if not reason:
                x = [details["momentum_60"],details["trend_300"],math.log(max(details["volatility"],1e-7))]
                for version in sorted({c["version"] for c in configs}):
                    try:
                        p = self.predict(version, x, checkpoint, slug, observed_at)
                        if not math.isfinite(p) or not 0 <= p <= 1:
                            raise ValueError("Invalid model probability")
                        probabilities[version] = p
                        self.model_failures.discard(version)
                    except MODEL_ERRORS as exc:
                        if version not in self.model_failures and "16 past" not in str(exc):
                            self.store.event("ERROR", f"Model {version} skipped: {type(exc).__name__}: {exc}")
                            self.model_failures.add(version)
            with self.store.connect() as db:
                db.execute("BEGIN IMMEDIATE")
                mode_row = db.execute("SELECT payload FROM state WHERE key='mode'").fetchone()
                emergency = db.execute("SELECT payload FROM state WHERE key='emergency'").fetchone()
                mode = json.loads(mode_row[0]) if mode_row else "OFF"
                if mode not in ("LEARN","SIMULATE") or emergency and json.loads(emergency[0]):
                    return
                if not db.execute("INSERT OR IGNORE INTO lab_processed VALUES (?,?)",(slug,checkpoint)).rowcount:
                    continue
                if not reason and book:
                    db.execute("INSERT OR IGNORE INTO lab_books VALUES (?,?,?)",
                               (slug,book["timestamp"],json.dumps(book)))
                for c in configs:
                    p = probabilities.get(c["version"])
                    if p is not None:
                        db.execute("INSERT OR IGNORE INTO lab_predictions VALUES (?,?,?,?,?,?,?)",
                                   (c["family"],c["version"],slug,checkpoint,observed_at,p,json.dumps(x)))
                    if mode != "SIMULATE":
                        continue
                    why = reason
                    if live_clock and (time.time()>deadline or time.time()>=details["window_end"]):
                        why = why or "MISSED_CHECKPOINT"
                    self.enter_timing(db,c,slug,observed_at,p,details,book,why)

    def enter_timing(self, db, config, slug, observed_at, p, details, book, reason):
        own = db.execute("SELECT status,slug FROM lab_orders WHERE config=? AND (status='OPEN' OR slug=?)",
                         (config["id"],slug)).fetchall()
        if any(row["slug"] == slug for row in own):
            return
        cash = db.execute("SELECT cash FROM lab_configs WHERE id=?", (config["id"],)).fetchone()[0]
        reason = reason or entry_block(dict(balance=cash,halted=None),own,config["stake"],observed_at,daily_cap=False)
        if not reason and p is None:
            reason = "MODEL_PREDICTION_UNAVAILABLE"
        if not reason and p == 0.5:
            reason = "MODEL_TIE_NO_DIRECTION"
        if not reason and (not book or not book["bids"] or not book["asks"]):
            reason = "NO_LIQUIDITY"
        if not reason:
            side = "UP" if p > 0.5 else "DOWN"
            fill = execute(book,side,budget=config["stake"],theta=details["theta"],
                           tick=details["tick"],quantum=details["quantum"])
            if not fill["quantity"]:
                reason = "NO_LIQUIDITY"
        if reason:
            db.execute("INSERT OR IGNORE INTO lab_skips VALUES (?,?,?,?)",
                       (config["id"],slug,observed_at,reason))
            return
        audit = dict(prediction=details,fill=fill,probability=p,exit=config["exit"],
                     version=config["version"],source="FIXED TIMING SHADOW",
                     book_reference=dict(slug=slug,timestamp=book["timestamp"],table="lab_books"))
        inserted = db.execute("""INSERT OR IGNORE INTO lab_orders
            (config,slug,side,time,quantity,remaining,cost,fees,status,details) VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (config["id"],slug,side,observed_at,fill["quantity"],fill["quantity"],fill["total"],
             fill["fee"],"OPEN",json.dumps(audit)))
        if inserted.rowcount and not db.execute("UPDATE lab_configs SET cash=cash-? WHERE id=? AND cash>=?",
                                                (fill["total"],config["id"],fill["total"])).rowcount:
            raise ValueError("Critical accounting error: shadow debit failed")

    def exit_and_settle(self, now):
        book = self.store.get("book")
        fresh = not self.paper.data_block(now)
        with self.store.connect() as db:
            orders = [dict(r) for r in db.execute("SELECT * FROM lab_orders WHERE status='OPEN'")]
        for o in orders:
            d = json.loads(o["details"])
            terms = d["prediction"]
            payout = None
            fill = None
            with self.store.connect() as db:
                outcome = db.execute(
                    "SELECT * FROM verified_markets WHERE slug=?", (o["slug"],)
                ).fetchone()
            if outcome and now >= outcome["end"]:
                payout = o["remaining"] if o["side"] == outcome["outcome"] else 0
            elif (
                fresh
                and self.store.get("mode") == "SIMULATE"
                and not self.store.get("emergency", False)
                and book
                and book["slug"] == o["slug"]
                and o["time"] < now < terms["window_end"]
                and d["exit"] != "HOLD"
            ):
                if any(
                    obs.get("book_timestamp") == book["timestamp"]
                    for obs in d.get("exit_observations", [])
                ):
                    continue  # Do not reuse a quote to fill a partial exit repeatedly.
                target = 1.4 * o["cost"]
                d["target_impossible"] = (
                    target > o["quantity"]
                )  # Even a $1 settlement cannot meet this target.
                if d["exit"] == "TAKE_PROFIT_1.4" and d["target_impossible"]:
                    continue
                fill = execute(
                    book,
                    o["side"],
                    quantity=o["remaining"],
                    buying=False,
                    theta=terms["theta"],
                    tick=terms["tick"],
                    quantum=terms["quantum"],
                )
                if not fill["quantity"]:
                    continue
                should_exit = False
                if d["exit"] == "TAKE_PROFIT_1.4":
                    should_exit = fill["total"] / fill["quantity"] >= target / o["quantity"]
                else:
                    p, features = self.paper.probability(now)
                    if p is not None:
                        x = [
                            features["momentum_60"],
                            features["trend_300"],
                            math.log(max(features["volatility"], 1e-7)),
                        ]
                        try:
                            p = self.predict(d["version"], x, terms["checkpoint"], o["slug"], now)
                        except MODEL_ERRORS:
                            continue
                        should_exit = (
                            fill["total"]
                            > (p if o["side"] == "UP" else 1 - p) * fill["quantity"] + 0.01
                        )
                if not should_exit:
                    continue
            else:
                continue
            with self.store.connect() as db:
                db.execute("BEGIN IMMEDIATE")
                current = db.execute(
                    "SELECT * FROM lab_orders WHERE id=? AND status='OPEN'", (o["id"],)
                ).fetchone()
                if not current or abs(current["remaining"] - o["remaining"]) > 1e-9:
                    continue
                remaining = 0 if payout is not None else max(0, o["remaining"] - fill["quantity"])
                proceeds = o["proceeds"] + (payout if payout is not None else fill["total"])
                closed = remaining < terms["quantum"] / 2
                d.setdefault("exit_observations", []).append(
                    dict(
                        time=now,
                        book_timestamp=book["timestamp"] if fill else None,
                        fill=fill,
                        settlement=dict(outcome) if payout is not None else None,
                    )
                )
                db.execute(
                    "UPDATE lab_orders SET remaining=?,proceeds=?,fees=fees+?,status=?,pnl=?,settled=?,details=? WHERE id=?",
                    (
                        remaining,
                        proceeds,
                        fill["fee"] if fill else 0,
                        "SETTLED" if closed else "OPEN",
                        proceeds - o["cost"] if closed else None,
                        now if closed else None,
                        json.dumps(d),
                        o["id"],
                    ),
                )
                db.execute(
                    "UPDATE lab_configs SET cash=cash+? WHERE id=?",
                    (payout if payout is not None else fill["total"], o["config"]),
                )

    def leaderboard(self):
        with self.store.connect() as db:
            rows = []
            for config in db.execute("SELECT * FROM lab_configs").fetchall():
                c = dict(config)
                orders = [
                    dict(r)
                    for r in db.execute(
                        "SELECT id,slug,time,cost,status,pnl,settled FROM lab_orders WHERE config=? ORDER BY settled,id",
                        (c["id"],),
                    )
                ]
                done = [o for o in orders if o["pnl"] is not None]
                skips = db.execute(
                    "SELECT count(*) FROM lab_skips WHERE config=?", (c["id"],)
                ).fetchone()[0]
                equity = peak = 100
                dd = 0
                for o in done:
                    equity += o["pnl"]
                    peak = max(peak, equity)
                    dd = max(dd, peak - equity)
                loss = -sum(min(0, o["pnl"]) for o in done)
                profit = sum(max(0, o["pnl"]) for o in done)
                c.update(
                    scope="FORWARD SHADOW",
                    profitability="UNKNOWN" if not done else "OBSERVED SIMULATION ONLY",
                    net_profit=sum(o["pnl"] for o in done) if done else None,
                    return_percent=(equity - 100) if done else None,
                    win_rate=sum(o["pnl"] > 0 for o in done) / len(done) if done else None,
                    maximum_drawdown=dd if done else None,
                    profit_factor=profit / loss if loss else None,
                    trades=len(done),
                    skips=skips,
                    test_start=min((o["time"] for o in orders), default=None),
                    test_end=max((o["settled"] or o["time"] for o in orders), default=None),
                    data_completeness="Observed forward decisions only; not a historical-week backtest",
                    calibration=None,
                )
                rows.append(c)
        return dict(
            planned_configurations=432,
            configurations=sorted(
                rows,
                key=lambda c: (c["net_profit"] is not None, c["net_profit"] or 0),
                reverse=True,
            ),
            models=self.models.catalog(),
            warning="Multiple comparisons increase overfitting risk. Fresh out-of-sample validation is required; historical rank does not authorize promotion.",
        )
