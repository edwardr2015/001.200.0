'use strict';
const $ = id => document.getElementById(id);
const money = n => n == null ? '—' : new Intl.NumberFormat('en-US', {style:'currency',currency:'USD'}).format(n);
const ageText = n => n == null ? 'No observation yet' : n < 60 ? `${Math.floor(n)}s old` : `${Math.floor(n / 60)}m ${Math.floor(n % 60)}s old`;
const genericError = value => (value||'').split('\n')[0].replace(/https?:\/\/[^\s'"<>]+/gi,'[endpoint]').replace(/CF Benchmarks|Polymarket US|Coinbase(?: Exchange)?|Kraken|BRTI|cpc-btc-updown-5m-[\w-]+/gi,'market feed');
const cents = n => n == null ? '—' : `${(n * 100).toFixed(1)}¢`;
let interval = 15, line = null, chart = null, series = null, initialized = false, latest = null, receivedAt = 0;
try {
  chart = LightweightCharts.createChart($('chart'), {
    autoSize:true, layout:{background:{color:'#101825'},textColor:'#8995a8',fontSize:10},
    grid:{vertLines:{color:'#1a2535'},horzLines:{color:'#1a2535'}},
    rightPriceScale:{borderColor:'#243043'},timeScale:{borderColor:'#243043',timeVisible:true,secondsVisible:true},
    crosshair:{mode:LightweightCharts.CrosshairMode.Normal},
    localization:{timeFormatter:t=>new Date(t*1000).toISOString().slice(11,19)+' UTC'}
  });
  series = chart.addCandlestickSeries({upColor:'#4bd6a0',downColor:'#ef7887',borderVisible:false,wickUpColor:'#4bd6a0',wickDownColor:'#ef7887',priceLineColor:'#e8b45a'});
} catch (e) { $('chart-empty').textContent = 'Chart could not load. Market values remain available below.'; }

function textRow(parent, label, value, className='') {
  const el = document.createElement('div'); el.className=className;
  const a=document.createElement('span'), b=document.createElement('span');
  a.textContent=label; b.textContent=value; el.append(a,b); parent.append(el); return el;
}

function render(s) {
  latest=s; receivedAt=Date.now();
  $('reference-price').textContent=money(s.reference?.price);
  $('spot-price').textContent=money(s.spot?.price);
  $('reference-age').textContent=`${s.health.reference.status.toUpperCase()} · ${ageText(s.health.reference.age_seconds)} · source timestamp`;
  $('spot-age').textContent=`${s.health.spot.status.toUpperCase()} · ${ageText(s.health.spot.age_seconds)} · ${s.spot?.fallback?'backup feed':'spot price'}`;
  const m=s.market, t=m?.assetPriceTerms;
  $('market-dot').classList.toggle('online',s.market_active && s.health.market.status==='connected');
  $('market-window').textContent=t ? `${new Date(t.windowStart).toISOString().slice(11,16)}–${new Date(t.windowEnd).toISOString().slice(11,16)} UTC · 5-minute window` : 'No verified active contract';
  $('price-to-beat').textContent=money(t?.priceToBeat?.value);
  $('contract-status').textContent=s.market_active ? 'Verified contract · currently open' : 'No verified open contract · last observation shown';
  const book=s.book, bid=book?.bids[0]?.price, ask=book?.asks[0]?.price;
  $('up-price').textContent=cents(ask);
  $('down-price').textContent=cents(bid == null ? null : 1-bid);
  $('spread').textContent=bid == null || ask == null ? '—' : cents(ask-bid);
  $('book-status').textContent=`${s.health.market.status.toUpperCase()} · ${ageText(s.health.market.age_seconds)}`;
  $('book-levels').replaceChildren();
  if (book) for(let i=0;i<3;i++) {
    const a=book.bids[i],b=book.asks[i];
    const row=textRow($('book-levels'),a?`${cents(a.price)} · ${a.quantity.toFixed(2)}`:'—',b?`${cents(b.price)} · ${b.quantity.toFixed(2)}`:'—');
    row.children[0].className='book-bid';row.children[1].className='book-ask';
  }
  if(series){
    if(line)series.removePriceLine(line);
    line=t?.priceToBeat ? series.createPriceLine({price:Number(t.priceToBeat.value),color:'#8faad9',lineWidth:1,lineStyle:2,axisLabelVisible:true,title:'Open ref'}) : null;
  }
  $('connections').replaceChildren();
  for(const [key,label] of [['reference','Settlement reference'],['market','Order book'],['spot','BTC/USD spot']]){
    const h=s.health[key],row=textRow($('connections'),label,h.status.toUpperCase(),'connection');
    const small=document.createElement('small');small.textContent=ageText(h.age_seconds);row.children[0].append(small);
    row.children[1].className=`badge ${h.status}`;if(h.error)row.title=genericError(h.error);
  }
  $('events').replaceChildren();
  for(const e of s.events){const el=document.createElement('div');el.className='event';el.textContent=`${new Date(e.time*1000).toISOString().slice(11,19)} UTC · ${e.level} · ${genericError(e.message)}`;$('events').append(el);}
  const names = ['reference','market','spot'];
  const status = ['disconnected','refreshing','delayed','connected'].find(
    value=>names.some(name=>s.health[name].status===value));
  setFeedIndicator(status);
  $('feed-diagnostics').replaceChildren();
  for(const name of names){
    const h=s.health[name];
    textRow($('feed-diagnostics'),name,
      `${h.status} · ${ageText(h.age_seconds)} · last success ${h.last_success ? new Date(h.last_success*1000).toISOString() : '—'}${h.error ? ' · '+genericError(h.error) : ''}`,
      'connection');
  }
  $('notice').classList.toggle('warning',s.emergency);
  $('notice').textContent=s.emergency?'Emergency stop active. Review the request in Settings.':
    s.mode==='OFF'?'OFF · Collection and settlement continue.':
    s.mode==='LEARN'?'LEARN · Predictions only.':'SIMULATE · Adaptive entries and fixed-time shadow accounts.';
  document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===s.mode));
  const pred=s.prediction;
  const call=s.decision_display?.call;
  renderDirection($('ai-decision'),$('ai-tally'),s.decision_display);
  renderBenchmark($('ai-results'),s.benchmark_results);
  $('direction-quotes').hidden=!call;
  $('quote-pair').hidden=!call;
  $('model-probabilities').hidden=!call;
  $('ai-reason').textContent=call?`Momentum call at +${call.checkpoint}s`:'Waiting for an eligible checkpoint';
  $('model-probabilities').textContent=call&&pred&&pred.slug===m?.slug&&pred.up!=null?
      `${(pred.up*100).toFixed(1)}% UP / ${((1-pred.up)*100).toFixed(1)}% DOWN`:'Unavailable';
  tick();
}

function setFeedIndicator(status){
  const indicator=$('feed-indicator');
  indicator.dataset.status=status;
  indicator.textContent=status.charAt(0).toUpperCase()+status.slice(1);
}

function tick(){
  const now=latest ? latest.server_time+(Date.now()-receivedAt)/1000 : Date.now()/1000;
  $('clock').textContent=new Date(now*1000).toISOString().slice(11,19)+' UTC';
  const end=latest?.market?.assetPriceTerms?.windowEnd;
  const n=end?Math.max(0,Math.ceil(Date.parse(end)/1000-now)):null;
  $('countdown').textContent=n==null?'—:—':`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
  if(receivedAt && Date.now()-receivedAt>10000)setFeedIndicator('disconnected');
  if((receivedAt && Date.now()-receivedAt>10000) || n===0){
    renderDirection($('ai-decision'),$('ai-tally'),null);
    $('direction-quotes').hidden=true;
    $('quote-pair').hidden=true;
    $('model-probabilities').hidden=true;
  }
}
async function getJSON(url){const r=await fetch(url);if(r.status===401){location.href='/login';throw new Error('Sign in required');}if(!r.ok)throw new Error(`HTTP ${r.status}`);return r.json();}
async function refresh(){
  try{render(await getJSON('/api/state'));}catch(e){setFeedIndicator('disconnected');}
  setTimeout(refresh,2000);
}
async function candles(){
  const requested=interval;
  try{const data=await getJSON(`/api/candles?interval=${requested}`);if(requested!==interval)return;
    if(series){series.setData(data.candles);$('chart-empty').hidden=!!data.candles.length;if(!initialized&&data.candles.length){chart.timeScale().fitContent();initialized=true;}}
    const partial=data.candles.filter(c=>!c.complete).length;
    $('candle-info').textContent=`${data.candles.length} observed candles · ${partial} partial / gapped · UTC`;
  }catch(e){$('candle-info').textContent='Chart refresh failed · last observations retained';}
}
document.querySelectorAll('[data-interval]').forEach(b=>b.addEventListener('click',()=>{interval=Number(b.dataset.interval);initialized=false;document.querySelectorAll('[data-interval]').forEach(x=>x.classList.toggle('selected',x===b));candles();}));
async function control(action){
  try{const r=await fetch(`/api/control/${action}`,{method:'POST',headers:{'X-Prophet-Control':'local-dashboard'}});if(!r.ok)throw new Error((await r.json()).detail||`HTTP ${r.status}`);render(await getJSON('/api/state'));}
  catch(e){$('notice').classList.add('warning');$('notice').textContent=`Control failed: ${e.message}. Check the local service.`;}
}
$('start').onclick=()=>control('start');$('stop').onclick=()=>control('stop');$('emergency').onclick=()=>control('emergency');$('reset').onclick=()=>control('review-reset');
$('settings').onclick=()=>{
  $('settings-dialog').showModal();
  loadInterventions();
};
async function loadInterventions(){
  const panel=$('interventions');
  try{
    const items=await getJSON('/api/interventions');
    panel.replaceChildren();
    if(!items.length){panel.textContent='No requests.';return;}
    for(const item of items){
      const row=document.createElement('section'), text=document.createElement('p');
      text.textContent=`${item.status} · ${item.request}`;
      row.append(text);
      if(item.status==='PENDING'){
        const note=document.createElement('input');
        note.placeholder='Optional response';
        note.setAttribute('aria-label','Optional response to review request');
        note.maxLength=500;
        row.append(note);
        for(const action of ['approve','deny']){
          const button=document.createElement('button');
          button.type='button';
          button.className='button';
          button.textContent=action==='approve'?'Approve':'Deny';
          button.disabled=window.prophetRole==='viewer';
          button.onclick=async()=>{
            try{
              const result=await fetch(`/api/interventions/${item.id}/${action}`,{
                method:'POST',headers:{'Content-Type':'application/json','X-Prophet-Control':'local-dashboard'},
                body:JSON.stringify({note:note.value})});
              const data=await result.json();
              if(!result.ok)throw new Error(data.detail);
              $('intervention-feedback').textContent=data.message;
              await loadInterventions();
            }catch(error){$('intervention-feedback').textContent=error.message;}
          };
          row.append(button);
        }
      }
      panel.append(row);
    }
  }catch(error){panel.textContent='Review requests unavailable.';}
}
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=async()=>{
  try{const r=await fetch(`/api/mode/${b.dataset.mode}`,{method:'POST',headers:{'X-Prophet-Control':'local-dashboard'}});if(!r.ok)throw new Error((await r.json()).detail);render(await getJSON('/api/state'));}
  catch(e){alert(e.message);}
});
async function paper(){
  try{
    const s=await getJSON('/api/paper');$('accounts').replaceChildren();
    for(const a of s.accounts.filter(a=>a.id.startsWith('adaptive-'))){
      const el=document.createElement('div'),title=document.createElement('span'),balance=document.createElement('strong'),detail=document.createElement('p');
      title.textContent=`ADAPTIVE · $${a.budget} fixed stake`;balance.textContent=money(a.balance);detail.textContent=`Net ${money(a.realized)} · today ${money(a.day_pnl)} · ${a.win_rate==null?'—':(a.win_rate*100).toFixed(1)+'%'} wins · losses ${a.streak}`;
      el.append(title,balance,detail);if(a.halted){const h=document.createElement('small');h.textContent=a.halted;h.className='loss';el.append(h);}$('accounts').append(el);
    }
    const benchmark=s.accounts.find(a=>a.id==='adaptive-1');
    if(benchmark){
      $('games-played').textContent=benchmark.trades;
      $('games-won').textContent=benchmark.wins;
      $('games-lost').textContent=benchmark.losses;
      $('games-pnl').textContent=benchmark.trades?money(benchmark.realized):'—';
    }
    $('account-detail').textContent='Games played counts settled rounds in the adaptive benchmark account. A flat result counts as played. Individual balances and stakes are available above.';
    const evaluation=s.adaptive_decision, active=latest?.market_active && latest?.market?.slug===evaluation?.slug;
    if(active && latest.mode!=='OFF'){
      const d=JSON.parse(evaluation.details), volatility=d.volatility==null?'':` · recent volatility ${(100*d.volatility).toFixed(3)}%`;
      const status=evaluation.decision==='UP'||evaluation.decision==='DOWN'?`Paper entry ${evaluation.decision}`:evaluation.decision==='WAIT'?'Evaluating':evaluation.decision;
      $('adaptive-status').textContent=`${status} · ${evaluation.reason.toLowerCase().replaceAll('_',' ')}${volatility}`;
    }else{
      $('adaptive-status').textContent=latest?.mode==='OFF'?'Adaptive entries are off.':'Waiting for an eligible market.';
    }
    $('paper-summary').textContent=s.experiment?`Seven-day experiment: ${s.experiment.status} · ${new Date(s.experiment.start*1000).toISOString()} to ${new Date(s.experiment.end*1000).toISOString()} · model frozen: ${s.experiment.model}`:'Experiment not started. SIMULATE starts the seven-day clock. Entries wait for verified data.';
    $('orders').replaceChildren();
    for(const o of s.orders.filter(o=>o.account.startsWith('adaptive-'))){const tr=document.createElement('tr');for(const v of [new Date(o.time*1000).toISOString().slice(11,19),o.account,o.side,o.quantity.toFixed(2),money(o.cost),o.status,o.pnl==null?'Pending':money(o.pnl)]){const td=document.createElement('td');td.textContent=v;tr.append(td);}$('orders').append(tr);}
    if(!$('orders').children.length){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=7;td.textContent='No paper trades recorded. SKIP is a valid outcome.';tr.append(td);$('orders').append(tr);}
    $('risk-events').replaceChildren();for(const e of s.risk_events){const d=document.createElement('div');d.className='event';d.textContent=`${new Date(e.time*1000).toISOString()} · ${e.account||'All accounts'} · ${e.reason}${e.reviewed?' · reviewed':''}`;$('risk-events').append(d);}
    for(const e of s.skips||[]){const d=document.createElement('div');d.className='event';d.textContent=`${e.account} · ${e.reason} · ${e.slug}`;$('risk-events').append(d);}
    if(series){const markers=new Map();for(const o of s.orders.filter(o=>o.account==='adaptive-1')){markers.set(o.slug,{time:Math.floor(o.time/interval)*interval,position:o.side==='UP'?'belowBar':'aboveBar',shape:o.side==='UP'?'arrowUp':'arrowDown',color:'#e8b45a',text:'PAPER '+o.side});}series.setMarkers([...markers.values()].sort((a,b)=>a.time-b.time));}
  }catch(e){$('paper-summary').textContent='Paper account status unavailable.';}
}
$('export').onclick=()=>{window.location.href='/api/export.xlsx';};
async function research(){
  try{
    const s=await getJSON('/api/research');$('research-panel').hidden=!s.available;if(!s.available)return;
    $('research-counts').replaceChildren();
    for(const [label,value] of [['15-second reference candles',s.reference_candles],['Resolved US BTC contracts',s.resolved_contracts],['Contracts with quotes',s.contracts_with_quotes]]){
      const el=document.createElement('div'),a=document.createElement('span'),b=document.createElement('strong');a.textContent=label;b.textContent=value.toLocaleString();el.append(a,b);$('research-counts').append(el);
    }
    const report=s.backtest?null:s.challenger||s.baseline;
    let summary=s.coverage?`${s.coverage.start.slice(0,10)} to ${s.coverage.end_exclusive.slice(0,10)} UTC (end excluded). `:'Import in progress. ';
    summary+=`${s.quarantined_quotes} inconsistent quote points quarantined. `;
    if(s.backtest)summary+='Historical execution audit: earlier display-price P&L is withdrawn when timestamps conflict with causal books. ';
    if(report){
      summary+='Chronological split: 4 training days / 1 validation day / 2 test days. ';
      for(const [name,parts] of Object.entries(report.models)){
        if(name==='momentum_baseline_v0.1'||name==='offline-logistic-v0.1')summary+=`${name}: ${(parts.test.directional_accuracy*100).toFixed(1)}% retrospective test direction accuracy (${parts.test.examples} rounds), Brier ${parts.test.brier_score.toFixed(3)}. `;
      }
    }
    summary+='No historical order-book quantities in this dataset; these are not tradable returns.';
    $('research-summary').textContent=summary;
    if(s.backtest){
      if(s.backtest.status?.startsWith('WITHDRAWN')){$('backtest-summary').textContent='WITHDRAWN: historical display prices conflict with entry-time order books. Previous P&L figures are not usable. A causal depth replay is required.';$('backtest-rows').replaceChildren();return;}
      $('backtest-summary').textContent=`Model: ${s.backtest.selected_model}. Test begins ${s.backtest.test_start}. Fill quantities are assumptions. Strict-entry revisions are exploratory; take-profit tests are disabled.`;
      $('backtest-rows').replaceChildren();for(const scenario of s.backtest.scenarios){const tr=document.createElement('tr');const a=scenario.accounts.filter(a=>a.id==='primary'||a.id.startsWith('research-'));for(const v of [scenario.label||`Assumed capacity ${scenario.capacity_fraction*100}%`,...a.map(a=>money(a.realized)),money(scenario.combined_main_pnl)]){const td=document.createElement('td');td.textContent=v;tr.append(td);}$('backtest-rows').append(tr);}
    }
  }catch(e){$('research-summary').textContent='Historical research status unavailable.';}
}
async function settingsStatus(){
  try{
    const alerts=await getJSON('/api/alerts');$('sms-status').textContent=`${alerts.configured?'Configured':'NOT CONFIGURED'} · ${alerts.recipient||'no destination'} · ${alerts.message}`;$('sms-test').disabled=!alerts.configured;
    const learning=await getJSON('/api/learning');$('learning-toggle').checked=true;
    $('learning-status').textContent=learning.status?`${learning.status.status} · ${learning.status.version||learning.status.message||''} · active model unchanged`:'Challengers wait for LEARN mode or the optional learning toggle.';
    const chosen=$('shadow-version').value;$('shadow-version').replaceChildren();
    for(const v of learning.versions){const o=document.createElement('option');o.value=v.version;o.textContent=`${v.version} · Brier ${v.brier.toFixed(3)}`;$('shadow-version').append(o);}
    if(chosen&&learning.versions.some(v=>v.version===chosen))$('shadow-version').value=chosen;else if(learning.shadow_version)$('shadow-version').value=learning.shadow_version;
    $('rollback').disabled=!learning.versions.length;
  }catch(e){$('learning-status').textContent='Settings status unavailable.';}
}
$('learning-toggle').onchange=async()=>{const action=$('learning-toggle').checked?'start':'stop';await fetch(`/api/learning/${action}`,{method:'POST',headers:{'X-Prophet-Control':'local-dashboard'}});};
$('sms-test').onclick=async()=>{const r=await fetch('/api/alerts/test',{method:'POST',headers:{'X-Prophet-Control':'local-dashboard'}});alert((await r.json()).message||'SMS test unavailable');};
$('rollback').onclick=async()=>{const r=await fetch(`/api/shadow-rollback/${encodeURIComponent($('shadow-version').value)}`,{method:'POST',headers:{'X-Prophet-Control':'local-dashboard'}});if(!r.ok)alert((await r.json()).detail);research();};
setInterval(settingsStatus,10000);settingsStatus();setInterval(tick,1000);setInterval(candles,3000);setInterval(research,10000);setInterval(paper,3000);refresh();candles();research();paper();
