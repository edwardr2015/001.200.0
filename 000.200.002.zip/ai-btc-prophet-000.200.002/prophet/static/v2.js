'use strict';
const pct=n=>n==null?'UNAVAILABLE':`${(n*100).toFixed(1)}%`;
const utcTime=t=>t==null?'NOT AVAILABLE':new Date(t*1000).toISOString();
const adminHeaders={'Content-Type':'application/json','X-Prophet-Control':'local-dashboard'};
function streakText(s){return `Current ${s.current||'none'} × ${s.length} · longest ${Object.entries(s.longest).map(([k,v])=>`${k} ${v}`).join(' / ')}`;}
function tileBoard(id,values){const node=$(id);node.replaceChildren();for(const v of values){const tile=document.createElement('div');tile.className=`history-tile ${v.value}`;tile.textContent=v.value;tile.title=v.slug;node.append(tile);}}
async function board(){try{const h=await getJSON('/api/history');tileBoard('market-tiles',h.markets.map(m=>({value:m.outcome,slug:m.slug})));$('market-history-summary').textContent=`${h.count}/50 verified settled rounds · UP ${h.up_percent==null?'UNAVAILABLE':h.up_percent.toFixed(1)+'%'} / DOWN ${h.down_percent==null?'UNAVAILABLE':h.down_percent.toFixed(1)+'%'}${h.complete?'':' · INSUFFICIENT DATA'}`;$('directional-streaks').textContent=streakText(h.directional_streaks);tileBoard('trade-tiles',h.trade_tiles);$('trade-history-summary').textContent=`${h.total_trades} settled trades · ${pct(h.win_rate)} win rate · SKIP never resets settled-trade streaks`;$('trade-streaks').textContent=streakText(h.trade_streaks);}catch(e){$('market-history-summary').textContent='History unavailable';}}
$('analyze-trends').onclick=async()=>{try{const r=await fetch('/api/analyze-trends',{method:'POST',headers:adminHeaders});const a=await r.json();if(!r.ok)throw new Error(a.detail);$('trend-result').textContent=`${a.status}: ${a.explanation} Prediction accuracy ${pct(a.accuracy)} (${a.prediction_count} recorded predictions); Brier ${a.brier==null?'INSUFFICIENT DATA':a.brier.toFixed(4)}. Recent log momentum ${a.recent_momentum==null?'UNAVAILABLE':a.recent_momentum.toFixed(5)}; volatility ${a.volatility==null?'UNAVAILABLE':a.volatility.toFixed(5)}. Calibration: ${a.calibration_status}.`;}catch(e){$('trend-result').textContent=e.message;}};
async function strategy(){try{const s=await getJSON('/api/strategies'),a=s.active;$('active-model').textContent=`${a.model} · strategy ${a.id}`;$('strategy-detail').textContent=`Adaptive entry · hold to settlement · $1 / $2 / $3 accounts · activated ${utcTime(a.time)} · ${Math.max(0,Math.floor((Date.now()/1000-a.time)/60))}m active`;$('strategy-reason').textContent=`Previous: ${a.previous||'NOT AVAILABLE'} · ${a.reason} · Git ${a.git_commit||'NOT AVAILABLE'} · $1 account in this segment ${s.performance?money(s.performance.net_profit):'UNAVAILABLE'} / ${s.performance?.trades||0} settled trades`;$('primary-history-select').replaceChildren();for(const prior of s.history.slice(1)){const option=document.createElement('option');option.value=prior.id;option.textContent=`Strategy ${prior.id}: ${prior.model} · ${utcTime(prior.time)}`;$('primary-history-select').append(option);}$('strategy-history').replaceChildren();for(const r of s.history){const p=document.createElement('p');p.className='event';p.textContent=`${utcTime(r.time)} · ${r.action} · ${r.previous||'none'} → ${r.model} · ${r.reason}`;$('strategy-history').append(p);}}catch(e){$('strategy-detail').textContent='Strategy status unavailable';}}
$('strategy-history-button').onclick=()=>{$('strategy-history').hidden=!$('strategy-history').hidden;};
async function compare(){try{const r=await getJSON('/api/models');$('lab-warning').textContent=r.warning;$('model-catalog').replaceChildren();for(const m of r.models){const el=document.createElement('div');const title=document.createElement('strong'),detail=document.createElement('p');title.textContent=m.id;const latestModel=m.versions[0],metadata=latestModel?JSON.parse(latestModel.metadata):{},test=metadata.test;detail.textContent=`${m.status} · ${m.versions.length} saved versions${test?` · historical accuracy ${pct(test.accuracy)} · Brier ${test.brier?.toFixed(4)} (${test.n} examples), not profitability`:''}`;el.append(title,detail);$('model-catalog').append(el);}$('leaderboard').replaceChildren();const chosen=$('promotion-config').value;$('promotion-config').replaceChildren();for(const c of r.configurations){const tr=document.createElement('tr');for(const value of [c.version,`${c.checkpoint}s`,c.exit,`$${c.stake}`,c.net_profit==null?'UNKNOWN':money(c.net_profit),pct(c.win_rate),c.maximum_drawdown==null?'UNKNOWN':money(c.maximum_drawdown),`${c.trades} / ${c.skips}`,`${c.status}; ${c.data_completeness}`]){const td=document.createElement('td');td.textContent=value;tr.append(td);}$('leaderboard').append(tr);if(c.status==='FORWARD SHADOW'&&c.exit==='HOLD'){const o=document.createElement('option');o.value=c.id;o.textContent=c.id;$('promotion-config').append(o);}}if([...$('promotion-config').options].some(o=>o.value===chosen))$('promotion-config').value=chosen;$('leaderboard-panel').open=true;}catch(e){$('lab-warning').textContent=`Comparison unavailable: ${e.message}`;}}
$('compare-models').onclick=compare;
async function promotePrimary(rollback){try{const r=await fetch('/api/promote',{method:'POST',headers:adminHeaders,body:JSON.stringify({configuration:$('promotion-config').value,reason:$('promotion-reason').value,strategy_id:Number($('primary-history-select').value),rollback})});const v=await r.json();if(!r.ok)throw new Error(v.detail);$('promotion-status').textContent='Configuration saved. Decisions OFF; bankroll and previous history preserved.';strategy();}catch(e){$('promotion-status').textContent=e.message;}}
$('promote-primary').onclick=()=>promotePrimary(false);$('rollback-primary').onclick=()=>promotePrimary(true);
$('logout').onclick=async()=>{await fetch('/api/logout',{method:'POST',headers:adminHeaders});location.href='/login';};
function timing(){if(!latest)return;const now=latest.server_time+(Date.now()-receivedAt)/1000;const t=latest.market?.assetPriceTerms;const start=t?Date.parse(t.windowStart)/1000:null;const elapsed=start==null?null:now-start;$('round-progress').value=elapsed==null?0:Math.max(0,Math.min(300,elapsed));const next=[15,30,45,60,75,90].find(c=>c>elapsed);$('next-checkpoint').textContent=elapsed==null?'Next checkpoint: UNAVAILABLE':next?`Next shadow checkpoint +${next}s · in ${Math.max(0,Math.ceil(next-elapsed))}s`:'Shadow checkpoints complete';const b=latest.book,bid=b?.bids[0]?.price,ask=b?.asks[0]?.price;$('quote-pair').textContent=bid==null||ask==null?'Bid/ask: UNAVAILABLE':`UP ${cents(bid)} / ${cents(ask)} · DOWN ${cents(1-ask)} / ${cents(1-bid)} · implied UP ${pct((bid+ask)/2)} (midpoint, not executable)`;}
setInterval(timing,1000);setInterval(board,5000);setInterval(strategy,10000);board();strategy();

getJSON('/api/session').then(s=>{window.prophetRole=s.role;$('logout').hidden=!s.auth_required;if(s.role==='viewer'){for(const selector of ['[data-mode]','#start','#stop','#emergency','#reset','#analyze-trends','#promote-primary','#rollback-primary','#sms-test','#rollback','#adaptive-shadow','#adaptive-approved']){document.querySelectorAll(selector).forEach(button=>{button.disabled=true;button.title='Read-only account';});}}}).catch(()=>{});



async function modelPerformance(){
  try{
    const data=await getJSON('/api/model-performance');
    const rows=document.createDocumentFragment();
    for(const item of data.models){
      const row=document.createElement('tr'), result=item.best;
      const model=document.createElement('th');
      model.scope='row';
      model.textContent=item.model;
      const version=document.createElement('small');
      version.className='model-version';
      version.textContent=result?.version || item.status.toLowerCase();
      model.append(version);row.append(model);
      const entry=result?(result.checkpoint==null?'Adaptive':`+${result.checkpoint}s`):'—';
      for(const [index,value] of [money(result?.pnl),result?.trades??0,result?.wins??0,result?.losses??0,pct(result?result.wins/result.trades:null),entry].entries()){
        const cell=document.createElement('td');cell.textContent=value;
        if(index===0 && result)cell.className=result.pnl<0?'loss':result.pnl>0?'profit':'';
        row.append(cell);
      }
      rows.append(row);
    }
    $('live-model-rows').replaceChildren(rows);
    const first=data.models[0],best=first?.best;
    const tied=best?data.models.filter(item=>item.best?.pnl===best.pnl):[];
    const scope=data.start==null?'':` · since ${new Date(data.start*1000).toLocaleString()}`;
    $('model-leader').textContent=best?
      `${best.pnl>0?'Highest profit':best.pnl<0?'Lowest loss':'Best result'} · ${tied.map(item=>item.model).join(', ')} · ${money(best.pnl)}${scope}`:
      `Waiting for official settlements${scope}.`;
  }catch(error){
    $('model-leader').textContent='Model results could not refresh. Any displayed rows are from the previous refresh.';
  }finally{
    setTimeout(modelPerformance,5000);
  }
}
modelPerformance();
