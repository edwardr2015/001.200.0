"""Local browser smoke test against an isolated empty database (never user accounts)."""

import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time
import urllib.request
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix="prophet-ui-") as folder:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    database = str(Path(folder) / "browser.sqlite")
    env = {
        **os.environ,
        "PROPHET_DB": database,
        "PROPHET_AUTH_FILE": str(Path(folder) / "auth.json"),
    }
    subprocess.run(
        [
            str(ROOT / ".venv/bin/python"),
            "-c",
            "import os;from prophet.auth import configure;configure(os.environ['PROPHET_AUTH_FILE'],'synthetic-browser-password')",
        ],
        env=env,
        cwd=ROOT,
        check=True,
    )
    code = f'from prophet.app import create_app;import uvicorn;uvicorn.run(create_app({database!r},collect=False),host="127.0.0.1",port={port})'
    log = open(Path(folder) / "server.log", "w")
    process = subprocess.Popen(
        [str(ROOT / ".venv/bin/python"), "-c", code], cwd=ROOT, env=env, stdout=log, stderr=log
    )
    try:
        base = f"http://127.0.0.1:{port}"
        for _ in range(100):
            try:
                urllib.request.urlopen(base + "/login", timeout=1)
                break
            except Exception:
                time.sleep(0.1)
        else:
            raise RuntimeError("Test web server did not start")
        with sync_playwright() as p:
            browser = p.chromium.launch(
                executable_path="/usr/bin/chromium", headless=True, args=["--no-sandbox"]
            )
            page = browser.new_page(viewport={"width": 1440, "height": 1100})
            errors = []
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.goto(base)
            page.locator("#username").fill("admin")
            page.locator("#password").fill("synthetic-browser-password")
            page.locator("#login-form button").click()
            page.wait_for_selector("#analyze-trends")
            page.locator("#analyze-trends").click()
            expect(page.locator("#trend-result")).to_contain_text("Insufficient Data")
            page.locator("#compare-models").click()
            page.wait_for_selector("#leaderboard tr:nth-child(144)")
            assert page.locator("#leaderboard").inner_text().count("UNKNOWN") >= 144
            page.locator('[data-mode="LEARN"]').click()
            page.wait_for_selector("[data-mode=LEARN].active")
            page.locator("#stop").click()
            page.wait_for_selector("[data-mode=OFF].active")
            assert page.locator(".mode.locked").is_disabled()
            page.locator("#emergency").click()
            expect(page.locator("#notice")).to_contain_text("EMERGENCY STOP")
            page.locator("#settings").click()
            page.locator("#reset").click()
            page.locator('[aria-label="Close settings"]').click()
            with page.expect_download() as download:
                page.locator("#export").click()
            file = download.value.path()
            assert Path(file).read_bytes().startswith(b"PK")
            output = ROOT / "data/v02-browser"
            output.mkdir(parents=True, exist_ok=True)
            page.screenshot(path=str(output / "desktop.png"), full_page=True)
            desktop_overflow = page.evaluate("document.documentElement.scrollWidth>innerWidth")
            page.set_viewport_size({"width": 390, "height": 844})
            page.wait_for_timeout(200)
            mobile_overflow = page.evaluate("document.documentElement.scrollWidth>innerWidth")
            page.screenshot(path=str(output / "mobile.png"), full_page=True)
            assert not desktop_overflow and not mobile_overflow
            assert not errors, errors
            result = dict(
                scope="ISOLATED EMPTY DATABASE / automated Chromium, not native Safari or macOS",
                desktop="1440x1100",
                mobile="390x844",
                javascript_errors=errors,
                horizontal_overflow=False,
                checks=[
                    "admin login",
                    "trend button",
                    "144-row comparison with UNKNOWN P&L",
                    "LEARN and OFF",
                    "LIVE locked",
                    "emergency and review",
                    "Excel download",
                    "desktop and mobile layout",
                ],
            )
            (output / "report.json").write_text(json.dumps(result, indent=2))
            print(json.dumps(result, indent=2))
            browser.close()
    finally:
        process.terminate()
        process.wait(timeout=10)
        log.close()
