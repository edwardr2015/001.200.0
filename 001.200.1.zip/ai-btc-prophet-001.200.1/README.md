# AI BTC Prophet Trader v0.2.1

Private Polymarket US fixed-time research. The app uses virtual balances and has no real-money order route.

## Start on macOS

1. Download and unzip the v0.2.1 ZIP. Keep your v0.2 ZIP and any existing installation as an archive.
2. Install Python 3.11 or newer. In Terminal, type `cd ` with a trailing space, drag the new project folder into Terminal, and press Return.
3. Run `bash "Start Prophet.command"`. Create the local admin password if prompted and leave Terminal open.
4. Open `http://127.0.0.1:8000` and sign in as `admin`. Choose **SIMULATE** to start the timing experiment. **LEARN** collects predictions without opening virtual positions.
5. Use **Settings → Feed diagnostics** for the provider error, source age, and last successful response. Select **Export Excel** for the audit workbook.

No Polymarket API key is needed for the included public feeds. Kraken is the primary spot display feed and Coinbase Exchange is its backup. Order execution research uses the official Polymarket US book and BRTI reference. Third-party spot prices cannot substitute for either. Use Control+C to stop the process. On restart, review any open positions and resolve the restart request in Settings before continuing. The local application is not served by GitHub.

## Timing experiment

Each available model version gets independent $100 accounts for each combination of 15, 30, 45, 60, 75 or 90 seconds after the market opens, $1/$2/$3 entry budget, and exit rule. A model above 50% UP attempts an UP buy. A model below 50% UP attempts a DOWN buy. A tie, unavailable prediction, stale or missing execution data, an open position, insufficient cash, or insufficient depth can cause a skip. A partially supported buy records its actual simulated size. Entries are captured at the checkpoint or within a three-second processing window. The app cannot enter after close. It never chooses a contrary side or uses expected value to veto the directional entry.

Use the workbook's **Timing vs 90s Matched** sheet to compare hold-to-settlement results for the same model version, stake and settled round. **Lab Trade History** and **Lab Skipped Markets** show fills and coverage. Matched results omit rounds where either side has no settled trade, so read matched counts alongside skips. Finding the best timing in one sample is exploratory. Test any winner on later rounds before drawing a profitability conclusion.

The timing accounts have no daily financial stop. Fixed budgets, available cash, one open position, one entry per market, and critical locks still apply. Execution models a fraction of displayed depth, adverse tick movement and fees. Actual execution and profitability can differ.

## Fresh data, bug log and review

The launcher uses `data/timing/` and leaves existing `data/` and research archives intact. It does not import past outcomes. The reference feed requests a recent candle window for feature warm-up. New market outcomes provide training labels. The built-in momentum model can run once complete candles arrive. Learned challengers need at least 200 labeled rounds and the relevant optional dependencies. Optional model libraries can be installed after the first launch with `.venv/bin/python -m pip install '.[research]'`. Restart after installing them. The initial experiment is time-limited to seven days.

The collectors use asynchronous requests, respect rate-limit backoff and keep actual source timestamps. An unchanged quote can be delayed while its provider is responding. Data delays skip affected checkpoints, and later checkpoints can resume on fresh data. The bot cannot recover quotes it never observed. This release uses polling, so it can miss changes between requests.

The workbook includes **Bug Log**, **Human Review** and **Model Timing Predictions**. For a critical lock, Settings presents a plain-English request. Approval records your decision and leaves the lock active until you review and clear it. Denial logs your response and creates one follow-up explaining why the lock remains. A second denial leaves the lock in place for manual investigation.

## Check the app and prepare a stream

After the first launch, a public-feed check from the project folder is:

```bash
.venv/bin/python -m scripts.verify_connections --output data/timing/live-check.json
```

A full automated check is:

```bash
.venv/bin/python -m pip install '.[dev]'
.venv/bin/python -m pytest -q
```

For a YouTube rehearsal, start with `PROPHET_PUBLIC_DISPLAY=1 bash "Start Prophet.command"`. Capture only `http://127.0.0.1:8000/display` in OBS. Confirm the view shows **read only** and **simulated results** before streaming. Keep the admin dashboard, Terminal, credentials and workbook outside the capture. YouTube and OBS setup are separate from the bot. The stream may show zero settled trades until the official outcomes arrive, and unavailable models can take longer than the first day to train.

## Decision and results display (001.200.1)

The dashboard and read-only stream view show **Waiting** until the current round has an eligible momentum call. They then show the direction in large type and the percentages of up to 20 recent directional calls. Skips and ties are excluded from that percentage. Settled wins, losses, longest streaks and net P&L since the experiment started use the single $1 momentum benchmark at 90 seconds and hold to settlement. The six experimental timings remain in the research workbook.
