'use strict';

const $ = id => document.getElementById(id);
const dollars = amount => new Intl.NumberFormat('en-US', {style:'currency',currency:'USD'}).format(amount);
let current = null, fetchedAt = 0, isViewer = false, controlPending = false;

function render(){
  const data = current;
  const now = data ? data.server_time + (performance.now()-fetchedAt)/1000 : 0;
  const connected = data && performance.now()-fetchedAt < 10000;
  const call = connected && data.close > now && data.call;
  const pick = $('observer-pick');
  pick.textContent = call ? call.decision : 'Waiting';
  pick.className = 'direction-call' + (call ? ' '+call.decision.toLowerCase() : '');
  $('observer-time').textContent = call ? 'Picked at +' + call.checkpoint + 's' : '';
  $('observer-status').textContent = !connected ? 'Connection unavailable' :
    data.emergency ? 'Observer · emergency stop' :
    !data.enabled || data.mode==='OFF' ? 'Observer · paused' :
    data.observer.mode==='DAILY_LIMIT' ? 'Observer · Learn mode · daily loss limit reached' :
    data.observer.mode==='LEARN' ? 'Observer · Learn mode · waiting for a correct settled pick' :
    'Observer · paper only';
  $('observer-balance').textContent = data ? 'Virtual cash '+dollars(data.observer.cash) : '';
  $('observer-start').disabled = isViewer || controlPending || !connected || data.emergency || (data.enabled && data.mode!=='OFF');
  $('observer-stop').disabled = isViewer || controlPending || !connected || !data.enabled;
}

async function refresh(){
  try {
    const response = await fetch('/api/pick');
    if(response.status===401){ location.href='/login'; return; }
    if(!response.ok)throw Error('Unable to refresh the observer');
    current=await response.json(); fetchedAt=performance.now();
  }catch(error){
    current=null;
  }
  render();
}

async function control(action){
  controlPending=true; render();
  $('observer-message').textContent='';
  try {
    const response=await fetch('/api/observer/'+action,{method:'POST',headers:{'X-Prophet-Control':'local-dashboard'}});
    if(!response.ok)throw Error((await response.json()).detail || 'Unable to change observer mode');
    await refresh();
  }catch(error){
    $('observer-message').textContent=error.message;
  }finally{
    controlPending=false; render();
  }
}

$('observer-start').onclick=()=>control('start');
$('observer-stop').onclick=()=>control('stop');
fetch('/api/session').then(r=>r.json()).then(data=>{isViewer=data.role==='viewer';render();}).catch(()=>{});
setInterval(refresh,1500);
setInterval(render,500);
refresh();
