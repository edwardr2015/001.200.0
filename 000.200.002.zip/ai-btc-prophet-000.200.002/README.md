# AI BTC Prophet Trader v0.2.2

Private Bitcoin prediction and paper trading on Polymarket US. All balances and fills are simulated.

## Start on macOS

1. Download and unzip `000.200.002.zip`. Install Python 3.11 or newer.
2. For a new install, open Terminal, type `cd ` with a trailing space, drag the project folder into Terminal, and press Return.
3. Run `bash "Start Prophet.command"` and leave Terminal open.
4. Open `http://127.0.0.1:8000`. The Mac launcher opens the local dashboard without a password. **LEARN** records predictions. **SIMULATE** starts a seven-day paper experiment. **Stop decisions** pauses entries while collection and settlement continue. Control+C stops the service.
5. Use **Settings → Feed diagnostics** for source timestamps and request status. Use **Export Excel** to save a workbook.

To upgrade an existing installation, stop the old process, keep a backup of its project folder, and copy the new app files into the existing project folder. From that existing folder you can use `rsync -a "/path/to/unzipped/ai-btc-prophet-000.200.002/" ./`, replacing the quoted path with the actual path. The archive contains app files only. Leave your existing `data/` and model directories in place. Start again from the existing folder so that SQLite and registered model artifacts stay at their current paths. The first upgraded launch archives the previous experiment's metadata and starts OFF. Existing balances, research, model versions, trades, and spreadsheets remain available. New research accounts start with $1,000 virtual cash each. The restart review still applies if the application stops with paper simulation on.

If you want password protection on the Mac, launch with `PROPHET_AUTH_REQUIRED=1 bash "Start Prophet.command"`. The launcher listens at loopback. Password-free access works from the same Mac. For an iPhone on a private network, keep authentication enabled and configure your private network interface and trusted host explicitly. The Mac launcher does not expose the dashboard to the network.

## Seven entry policies, one exit rule

- **Adaptive:** evaluates the verified five-minute market as observations arrive. It enters immediately on the first executable opportunity with estimated after-cost expected value of at least 3% of modeled cost. It can enter at any time from the official open up to the official close. No qualifying opportunity produces a final skip. There are three independent adaptive accounts.
- **Fixed-time shadows:** each available model runs at 15, 30, 45, 60, 75 and 90 seconds after the official open, using the model's direction at that checkpoint. A three-second processing window allows a fresh snapshot to arrive. Up to eight model families × six times × three account budgets creates 144 fixed-time accounts. With adaptive accounts, the maximum is 147. Optional dependencies and enough training data determine which model families can run.
- **All positions hold to official settlement.** Old early-exit and flip research remains archived. There is no daily financial shutdown. Critical locks, insufficient funds, one open position per account and one entry per account per market still apply.
- The fill model uses up to 25% of displayed depth, one adverse tick and fees, including a conservative fee coefficient of at least 0.095. One-cent asks and fills deploying less than 95% of the intended budget are rejected. Separate accounts are counterfactuals using the same market observations. Their results should not be summed as independent trades.

## Dashboard and later-entry audit

**Live model performance** ranks each model family by its best individual account's settled net dollar P&L in the current experiment. The leader is the highest profit or lowest loss. Games played, wins, losses, and win rate show the sample behind each result. The large adaptive scoreboard uses one reference account to count a round once. The large UP/DOWN call remains the fixed-time momentum forecast, with counts over the latest 20 published calls. An adaptive simulated entry appears in its own ledger.

**Later Entry Comparison** prices the same side and intended budget at +15, +30, +45, +60, +75 and +90 seconds after each actual adaptive entry, using observed quotes and the same cost assumptions. A comparable row reports both P&Ls after the official outcome and the difference. A missed, ineligible, or unfillable later entry leaves its counterfactual P&L blank. **Adaptive vs Fixed Timing** pairs both strategies on common officially settled rounds with recorded results, counting documented skips as zero. Fixed and adaptive strategies can differ in model or entry criteria, so that sheet compares strategies as a whole. **Timing vs 90s Matched** compares fixed setups for the same model version, stake, and settled round.

**Adaptive Labeled Observations** joins time-stamped pre-close predictions and feature audits to official outcomes. **Model Timing Predictions**, **UP DOWN History**, **Bug Log**, **Human Review**, and the raw ledgers remain available. Group all observations from one market together and split chronologically when building an alternate model. Use later markets for final evaluation. Rankings are exploratory and can change as rounds settle. Challenger training keeps the active model frozen during an experiment.

## Feeds and recovery

Public Polymarket US market metadata, order book, BRTI reference and settlements require no API key in this release. Kraken supplies separate BTC spot prices, with Coinbase Exchange as backup. Spot feeds do not supply Polymarket quotes or settlement labels.

Asynchronous polling keeps source timestamps and honors provider backoff. An unchanged quote can remain usable when the venue confirms that same open book within 10 seconds. BRTI must be within 30 seconds of its actual publication. Fresh input resumes paper evaluation after a temporary delay if no critical lock is active. Polling can miss price changes between requests. Only observations actually captured by the app can be used for a simulated fill or its comparison.

For a read-only public-feed check, run:

```bash
.venv/bin/python -m scripts.verify_connections --output data/timing/live-check.json
```

For the automated suite, run:

```bash
.venv/bin/python -m pip install '.[dev,research]'
.venv/bin/python -m pytest -q
```

To rehearse a YouTube stream, use `PROPHET_PUBLIC_DISPLAY=1 bash "Start Prophet.command"` and capture `http://127.0.0.1:8000/display` in OBS. Keep the dashboard controls, Terminal and private workbook outside the capture. GitHub stores the release archive. The dashboard runs on your computer.
