"""Loopback-only dashboard service. This application has no trading endpoints."""

import logging
from ipaddress import ip_address
import json
import os
import sqlite3
import time
from contextlib import asynccontextmanager, closing
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from .collector import Collector
from .adaptive_entry import BOOK_CONFIRM_MAX_AGE, REFERENCE_MAX_AGE
from .providers import timestamp, validate_market
from .store import Store
from .v2paper import Engine as PaperEngine
from .auth import Auth
from . import analytics, intervention
from .learning import Learning
from .lab import Lab
from .runtime import Runtime
from .alerts import Alerts

STATIC = Path(__file__).parent / "static"


def create_app(db_path=None, collect=True, auth_required=True):
    store = Store(db_path or os.getenv("PROPHET_DB", "data/prophet.sqlite3"))
    collector = Collector(store)
    paper = PaperEngine(store)
    learning = Learning(store, os.getenv("PROPHET_HISTORY_DB", "data/history.sqlite3"))
    # Legacy SmartResearch remains available for audit; v2 lab has independent positions.
    auth = Auth(store)
    lab = Lab(store, paper)
    paper.smart = lab
    runtime = Runtime(store, collector, paper)
    alerts = Alerts(store)

    @asynccontextmanager
    async def lifespan(app):
        logging.basicConfig(
            level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s"
        )
        logging.getLogger("httpx").setLevel(logging.WARNING)
        store.event("INFO", "Read-only research service started")
        if collect:
            await runtime.start()
            await collector.start()
            await paper.start()
            await learning.start()
            await alerts.start()
        yield
        await alerts.close()
        await runtime.close()
        await learning.close()
        await paper.close()
        await collector.close()

    app = FastAPI(title="AI BTC Prophet Trader", version="0.2.2", lifespan=lifespan)
    app.state.store = store
    app.state.collector = collector
    app.state.paper = paper
    app.state.learning = learning
    app.state.auth = auth
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=["127.0.0.1", "localhost", "[::1]", "testserver"]
        + [h.strip() for h in os.getenv("PROPHET_HOSTS", "").split(",") if h.strip()],
    )

    @app.middleware("http")
    async def security(request: Request, call_next):
        from fastapi.responses import JSONResponse, RedirectResponse

        if not auth_required:
            client = request.client.host if request.client else ""
            try:
                local = ip_address(client).is_loopback
            except ValueError:
                local = client == "testclient" and request.url.hostname == "testserver"
            if not local or request.url.hostname not in ("127.0.0.1", "localhost", "::1", "testserver"):
                return JSONResponse({"detail": "Password-free access is local to this computer"}, status_code=403)
            if request.url.path == "/login":
                return RedirectResponse("/", status_code=303)

        public = request.url.path in ("/login", "/api/login") or request.url.path.startswith(
            "/static/"
        )
        display = os.getenv("PROPHET_PUBLIC_DISPLAY") == "1" and request.url.path in (
            "/display",
            "/api/display",
        )
        role = auth.role(request.cookies.get("prophet_session")) if auth_required else "admin"
        if auth_required and not public and not display and not role:
            if request.url.path == "/":
                return RedirectResponse("/login", status_code=303)
            return JSONResponse({"detail": "Sign in required"}, status_code=401)
        if (
            role == "viewer"
            and request.method not in ("GET", "HEAD")
            and request.url.path != "/api/logout"
        ):
            return JSONResponse({"detail": "Read-only account"}, status_code=403)
        if request.method not in ("GET", "HEAD"):
            origin = request.headers.get("origin")
            if origin and origin != str(request.base_url).rstrip("/"):
                raise_error = {"detail": "Cross-origin control requests are forbidden"}
                from fastapi.responses import JSONResponse

                return JSONResponse(raise_error, status_code=403)
            if request.headers.get("x-prophet-control") != "local-dashboard":
                from fastapi.responses import JSONResponse

                return JSONResponse({"detail": "Missing dashboard control header"}, status_code=403)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"
        )
        return response

    @app.get("/api/session")
    def session(request: Request):
        return dict(
            role=auth.role(request.cookies.get("prophet_session")) if auth_required else "admin",
            auth_required=auth_required,
        )

    @app.get("/login")
    def login_page():
        return FileResponse(STATIC / "login.html")

    @app.post("/api/login")
    async def login(request: Request):
        if not auth.configured():
            raise HTTPException(503, "Run scripts/setup_auth.py locally first")
        body = await request.json()
        try:
            token, role = auth.login(
                str(body.get("username", "")), str(body.get("password", "")), request.client.host
            )
        except ValueError as exc:
            raise HTTPException(401, str(exc)) from exc
        from fastapi.responses import JSONResponse

        response = JSONResponse(dict(role=role))
        response.set_cookie(
            "prophet_session",
            token,
            httponly=True,
            samesite="strict",
            max_age=43200,
            secure=os.getenv("PROPHET_SECURE_COOKIES") == "1",
        )
        return response

    @app.post("/api/logout")
    def logout(request: Request):
        auth.logout(request.cookies.get("prophet_session"))
        response = Response(status_code=204)
        response.delete_cookie("prophet_session")
        return response

    @app.get("/api/models")
    def compare_models():
        return lab.leaderboard()

    @app.get("/api/model-performance")
    def model_performance():
        return lab.model_performance()

    @app.get("/api/adaptive")
    def adaptive_status():
        with store.connect() as db:
            rows = [
                dict(r)
                for r in db.execute("SELECT * FROM adaptive_selections ORDER BY time DESC LIMIT 50")
            ]
        summary = paper.summary()
        return dict(enabled=store.get("mode") == "SIMULATE",
                    policy="CONTINUOUS AFTER-COST EV", latest=summary["adaptive_decision"],
                    selections=rows)

    @app.post("/api/adaptive/{action}")
    def adaptive_control(action: str):
        if action not in ("shadow", "approved-simulation"):
            raise HTTPException(404, "Unknown adaptive action")
        if action == "approved-simulation":
            raise HTTPException(409, "Use SIMULATE to run continuous entries and independent timing shadows")
        try:
            lab.adaptive.enable(False)
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc
        return dict(enabled=action == "approved-simulation")

    @app.get("/api/strategies")
    def strategy_history():
        summary = paper.summary()
        return dict(
            active=summary["strategy"],
            history=summary["strategy_history"],
            performance=summary["strategy_performance"],
        )

    @app.post("/api/promote")
    async def promote_strategy(request: Request):
        from .promotion import promote, rollback_strategy

        body = await request.json()
        try:
            if body.get("rollback"):
                return rollback_strategy(
                    store, int(body.get("strategy_id", 0)), str(body.get("reason", ""))
                )
            return promote(
                store,
                str(body.get("configuration", "")),
                str(body.get("reason", "")),
                rollback=bool(body.get("rollback", False)),
            )
        except (OSError, ValueError) as exc:
            raise HTTPException(409, str(exc)) from exc

    def decision_display(market, now):
        active = market and validate_market(market, now)
        mode = store.get("mode", "OFF")
        with store.connect() as db:
            predicate = """decision IN ('UP','DOWN') AND up IS NOT NULL AND time<=?
                            AND json_extract(details,'$.protocol')='fixed-timing-v1'"""
            recent = db.execute(
                f"SELECT decision FROM v2_decisions WHERE {predicate} ORDER BY time DESC,checkpoint DESC LIMIT 20",
                (now,),
            ).fetchall()
            call = db.execute(
                f"""SELECT decision,checkpoint,time FROM v2_decisions
                    WHERE {predicate} AND slug=? ORDER BY time DESC,checkpoint DESC LIMIT 1""",
                (now,market["slug"]),
            ).fetchone() if active and mode in ("LEARN", "SIMULATE") and not store.get("emergency", False) else None
        up = sum(row["decision"] == "UP" for row in recent)
        count = len(recent)
        return dict(call=dict(call) if call else None, count=count, up_count=up, down_count=count-up,
                    up_percent=100*up/count if count else None,
                    down_percent=100*(count-up)/count if count else None)

    def benchmark_results(now):
        experiment = store.get("v2_experiment") or {}
        start = experiment.get("start")
        with store.connect() as db:
            rows = db.execute("""SELECT o.pnl FROM lab_orders o JOIN lab_configs c ON c.id=o.config
                WHERE c.id LIKE 'timing/%' AND c.version='momentum-v2' AND c.checkpoint=90
                AND c.exit='HOLD' AND c.stake=1 AND o.status='SETTLED' AND o.time>=? AND o.settled<=?
                ORDER BY o.settled,o.id""",(start,now)).fetchall() if start is not None else []
        pnl = [row["pnl"] for row in rows]
        values = ["WIN" if item>0 else "LOSS" if item<0 else "FLAT" for item in pnl]
        runs = analytics.streaks(values,"WIN","LOSS")
        return dict(start=start, wins=values.count("WIN"), losses=values.count("LOSS"),
                    flats=values.count("FLAT"), pnl=sum(pnl), current=runs["current"],
                    streak=runs["length"], longest_win=runs["longest"]["WIN"],
                    longest_loss=runs["longest"]["LOSS"])

    @app.get("/api/display")
    def public_data():
        if os.getenv("PROPHET_PUBLIC_DISPLAY") != "1":
            raise HTTPException(404, "Public display is disabled")
        with store.connect() as db:
            timing = [dict(row) for row in db.execute("""SELECT c.checkpoint, count(o.id) AS trades,
                sum(o.pnl) AS pnl FROM lab_configs c LEFT JOIN lab_orders o
                ON o.config=c.id AND o.status='SETTLED'
                WHERE c.id LIKE 'timing/%' AND c.family='momentum' AND c.exit='HOLD' AND c.stake=1
                GROUP BY c.checkpoint ORDER BY c.checkpoint""")]
        now = time.time()
        market = store.get("market")
        return dict(
            reference=store.get("reference"),
            spot=store.get("spot"),
            market=market,
            server_time=now,
            decision_display=decision_display(market, now),
            benchmark_results=benchmark_results(now),
            live_locked=True,
            timing=timing,
        )

    @app.get("/display")
    def public_display():
        if os.getenv("PROPHET_PUBLIC_DISPLAY") != "1":
            raise HTTPException(404, "Public display is disabled")
        return FileResponse(STATIC / "display.html")

    @app.get("/api/history")
    def history_board():
        return analytics.history(store)

    @app.post("/api/analyze-trends")
    def analyze_trends():
        return analytics.analyze(store)

    @app.get("/")
    def index():
        return FileResponse(STATIC / "index.html")

    @app.get("/api/state")
    def state():
        now = time.time()
        market = store.get("market")
        reference = store.get("reference")
        book = store.get("book")
        spot = store.get("spot")
        health = {}
        for name, value in [("reference", reference), ("market", book), ("spot", spot)]:
            h = store.get("health_" + name, {"ok": False, "checked": None, "error": None})
            age = now - value["timestamp"] if value else None
            checked = h.get("checked")
            last_success = h.get("last_success", checked if h.get("ok") else None)
            if not collector.enabled or (checked is not None and now-checked>30):
                status = "disconnected"
            elif checked is None:
                status = "refreshing"
            elif not h.get("ok"):
                status = "refreshing" if last_success is not None and now-last_success<=30 else "disconnected"
            elif age is None:
                status = "refreshing"
            elif (age < 0 or (name == "market" and now-checked > BOOK_CONFIRM_MAX_AGE)
                  or (name != "market" and age > REFERENCE_MAX_AGE)):
                status = "delayed"
            else:
                status = "connected"
            h.update(age_seconds=age, status=status, last_success=last_success,
                     source_timestamp=value["timestamp"] if value else None)
            health[name] = h
        active = bool(market and validate_market(market, now))
        if not active or not book or book["slug"] != market["slug"]:
            book = None
        return dict(
            version="0.2.2 · paper research",
            server_time=now,
            collecting=collector.enabled,
            emergency=store.get("emergency", False),
            mode=store.get("mode", "OFF"),
            live_locked=True,
            prediction=paper.summary()["prediction"],
            decision_display=decision_display(market, now),
            benchmark_results=benchmark_results(now),
            last_outcome=store.get("last_outcome"),
            model_version=paper.summary()["model"],
            reference=reference,
            spot=spot,
            market=market,
            market_active=active,
            seconds_remaining=max(0, timestamp(market["assetPriceTerms"]["windowEnd"]) - now)
            if market
            else None,
            book=book,
            health=health,
            availability=store.get("availability"),
            events=store.events(),
        )

    @app.get("/api/candles")
    def candles(interval: int = Query(15)):
        if interval not in (15, 30, 60):
            raise HTTPException(422, "Choose 15, 30 or 60 seconds")
        return dict(
            source="CF Benchmarks BRTI via Polymarket US",
            interval=interval,
            candles=store.candles(interval),
        )

    @app.get("/api/health")
    def health():
        s = state()
        return dict(
            service="running",
            providers=s["health"],
            live_trading=False,
            runtime=store.get("runtime_health"),
            last_backup=store.get("last_backup"),
        )

    @app.get("/api/research")
    def research():
        root = Path(os.getenv("PROPHET_HISTORY_DB", "data/history.sqlite3"))
        result = dict(available=False, active_model_changed=False, live_trading=False)
        if not root.exists():
            return result
        try:
            with closing(
                sqlite3.connect("file:" + str(root.resolve()) + "?mode=ro", uri=True)
            ) as db:
                result.update(
                    available=True,
                    reference_candles=db.execute("SELECT count(*) FROM reference15").fetchone()[0],
                    resolved_contracts=db.execute("SELECT count(*) FROM markets").fetchone()[0],
                    contracts_with_quotes=db.execute(
                        "SELECT count(DISTINCT slug) FROM quotes"
                    ).fetchone()[0],
                    quarantined_quotes=db.execute("SELECT count(*) FROM quote_issues").fetchone()[
                        0
                    ],
                )
        except sqlite3.Error:
            return dict(available=False, message="Historical dataset is being initialized")
        for name, filename in [
            ("coverage", "history-coverage.json"),
            ("baseline", "baseline-report.json"),
            ("challenger", "challenger-report.json"),
        ]:
            try:
                result[name] = json.loads((root.parent / filename).read_text())
            except (OSError, ValueError):
                result[name] = None
        try:
            result["coverage"] = json.loads(
                (root.parent / "history-14day-coverage.json").read_text()
            )
        except (OSError, ValueError):
            pass
        try:
            result["backtest"] = json.loads((root.parent / "backtest14/report.json").read_text())
        except (OSError, ValueError):
            result["backtest"] = None
        return result

    @app.post("/api/control/{action}")
    def control(action: str):
        if action == "start":
            try:
                paper.mode("SIMULATE")
            except ValueError as exc:
                raise HTTPException(409, str(exc)) from exc
        elif action == "stop":
            paper.mode("OFF")
        elif action == "emergency":
            store.put("emergency", True)
            paper.halt("EMERGENCY_STOP")
            collector.enabled = True  # Observation continues under the emergency latch.
        elif action == "review-reset":
            with store.connect() as db:
                unresolved = db.execute("""SELECT 1 FROM intervention_requests r
                    JOIN risk_events e ON r.issue=e.reason AND r.account IS e.account
                    WHERE e.reviewed IS NULL AND r.status IN ('PENDING','DENIED')
                    AND r.id=(SELECT max(id) FROM intervention_requests WHERE issue=r.issue AND account IS r.account)
                    LIMIT 1""").fetchone()
            if unresolved:
                raise HTTPException(409, "Review the request in Settings and approve it before clearing the lock.")
            paper.review()
            store.put("emergency", False)
        else:
            raise HTTPException(404, "Unknown control")
        store.event("INFO", "User control: " + action)
        return dict(ok=True, action=action)

    @app.get("/api/paper")
    def paper_state():
        return paper.summary()

    @app.get("/api/learning")
    def learning_state():
        with store.connect() as db:
            versions = [
                dict(r)
                for r in db.execute(
                    "SELECT version,time,brier,baseline_brier FROM model_runs ORDER BY id DESC LIMIT 30"
                )
            ]
            shadows = [
                dict(r)
                for r in db.execute(
                    "SELECT version,count(*) predictions,sum(outcome IS NOT NULL) evaluated,avg(brier) brier FROM model_shadows GROUP BY version"
                )
            ]
        return dict(
            enabled=store.get("learning_enabled", False),
            status=store.get("learning_status"),
            shadow_version=store.get("shadow_version"),
            versions=versions,
            shadows=shadows,
            active_model_unchanged=True,
        )

    @app.post("/api/learning/{action}")
    def learning_control(action: str):
        if action not in ("start", "stop"):
            raise HTTPException(404, "Unknown learning control")
        store.put("learning_enabled", action == "start")
        return dict(enabled=action == "start")

    @app.post("/api/shadow-rollback/{version}")
    def rollback(version: str):
        try:
            learning.rollback(version)
        except (OSError, ValueError) as exc:
            raise HTTPException(409, str(exc)) from exc
        return dict(shadow_version=version, active_model_unchanged=True)

    @app.get("/api/backtest")
    def backtest():
        try:
            return json.loads((Path(store.path).parent / "backtest14/report.json").read_text())
        except (OSError, ValueError):
            return dict(status="NOT_RUN", scenarios=[])

    @app.get("/api/interventions")
    def interventions():
        with store.connect() as db:
            return [dict(row) for row in db.execute("SELECT * FROM intervention_requests ORDER BY id DESC LIMIT 50")]

    @app.post("/api/interventions/{request_id}/{action}")
    async def decide_intervention(request_id: int, action: str, request: Request):
        if action not in ("approve", "deny"):
            raise HTTPException(404, "Unknown decision")
        body = await request.json()
        note = str(body.get("note", ""))[:500] if isinstance(body,dict) else ""
        status = "APPROVED" if action == "approve" else "DENIED"
        if not intervention.resolve(store,request_id,status,note):
            raise HTTPException(409, "Request is missing or already decided")
        return dict(status=status, message="Recorded. Safety controls remain in place.")

    @app.get("/api/alerts")
    def alert_state():
        return alerts.summary()

    @app.post("/api/alerts/test")
    def alert_test():
        if not alerts.configured():
            raise HTTPException(409, "SMS provider is not configured")
        import uuid

        with store.connect() as db:
            db.execute(
                "INSERT INTO alert_outbox(event_key,time,reason,body,status,updated) VALUES (?,?,?,?,?,?)",
                (
                    "test:" + str(uuid.uuid4()),
                    time.time(),
                    "TEST",
                    "BTC Prophet PAPER: this is your requested SMS test. No real-money trading is enabled.",
                    "PENDING",
                    time.time(),
                ),
            )
        return dict(status="PENDING", message="Queued test; check provider delivery status")

    @app.get("/api/export.xlsx")
    def export():
        from .v2reporting import workbook

        return Response(
            workbook(store, paper),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": 'attachment; filename="BTC-Prophet-Paper-Report.xlsx"'},
        )

    @app.post("/api/mode/{value}")
    def mode(value: str):
        try:
            paper.mode(value)
        except ValueError as exc:
            raise HTTPException(423 if value == "LIVE" else 409, str(exc)) from exc
        return dict(mode=value)

    app.mount("/static", StaticFiles(directory=STATIC), name="static")
    return app


app = create_app(auth_required=os.getenv("PROPHET_AUTH_REQUIRED", "1") != "0")
